/* Media Show BCN — cotizador 3D. Los packs y extras llegan de WooCommerce en window.MSB. */
(function () {
  'use strict';
  if (!document.getElementById('view-quoter')) return;
  const D = window.MSB || { packs: [], extras: [], settings: {} };
  const S = Object.assign({ whatsapp: '34615782087', iva: 21, deposit: 50, includedHours: 6, extraHour: 75 }, D.settings);
  const PACKS = D.packs || [];
  const EXTRAS = D.extras || [];
  const packById = id => PACKS.find(p => p.id === Number(id));
  const isLed = ex => /^led_/.test(ex.model);
  const LEDS = EXTRAS.filter(isLed);
  const TARIMA = EXTRAS.find(ex => ex.model === 'tarima');
  const isSpecial = ex => isLed(ex) || ex === TARIMA;
  const dec = v => String(+Number(v).toFixed(2)).replace('.', ',');
  const tarimaM2 = t => Math.ceil(t.w * t.d);
  const priceTxt = (price, max) => price === null ? 'A consultar' : '+' + eur0(price) + (max > 1 ? ' / ud.' + (max < 10 ? ' (máx. ' + max + ')' : '') : '');

  const ICONS = {
    totem: '<rect x="7" y="2" width="10" height="17" rx="1.5"/><path d="M12 19v3M8 22h8"/>',
    heads: '<circle cx="12" cy="8" r="4"/><path d="M8 12l-3 8M16 12l3 8M12 12v9"/>',
    bars: '<rect x="3" y="9" width="18" height="6" rx="1.5"/><path d="M7 15v4M17 15v4"/>',
    led: '<rect x="2" y="4" width="20" height="13" rx="1.5"/><path d="M8 21h8M12 17v4"/>',
    stream: '<rect x="2" y="6" width="14" height="12" rx="2"/><path d="M16 10l6-3v10l-6-3z"/>',
    smoke: '<path d="M6 17h12a3 3 0 000-6 4.5 4.5 0 00-8.8-1.2A3.5 3.5 0 006 17z"/>',
    screen55: '<rect x="3" y="4" width="18" height="11" rx="1.2"/><path d="M12 15v6M8 21h8"/>',
    truss: '<path d="M3 6h18M3 10h18M3 6l4 4 4-4 4 4 4-4M5 10v11M19 10v11"/>',
    booth: '<rect x="3" y="10" width="18" height="10" rx="1.5"/><circle cx="8" cy="7" r="2.5"/><circle cx="16" cy="7" r="2.5"/>',
    dj: '<circle cx="12" cy="7" r="3.5"/><path d="M7.5 7a4.5 4.5 0 019 0M5 21c0-3.5 3.1-6 7-6s7 2.5 7 6"/>',
    spk: '<rect x="6" y="2" width="12" height="20" rx="2"/><circle cx="12" cy="14" r="4"/><circle cx="12" cy="6.5" r="1.5"/>',
    mic: '<rect x="9" y="2" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0014 0M12 18v4"/>',
    lectern: '<path d="M6 7h12l-2 4H8z"/><path d="M9 11v9M15 11v9M7 20h10"/>',
    tarima: '<path d="M2 12h20v4H2z"/><path d="M4 16v5M20 16v5M15 12V9h5"/>',
    '': '<path d="M4 7l8-4 8 4v10l-8 4-8-4z"/><path d="M4 7l8 4 8-4M12 11v10"/>'
  };

  const PILLARS = [
    { eyebrow: '01 · Sonido & Microfonía', title: 'Sistemas RCF & Audio Digital',
      body: 'Columnas activas RCF EVOX 12, subgraves de alta presión acústica, consolas digitales y microfonía inalámbrica sin interferencias para discursos, música en directo y DJ.',
      spec: 'Sonido limpio y homogéneo con técnico de sonido y pruebas previas.', preset: 'corporate', dm: 'dm', models: {} },
    { eyebrow: '02 · Iluminación & Rigging', title: 'Cabezas Móviles, Barras LED y Truss',
      body: 'Estructuras de truss de aluminio certificadas, cabezas móviles Stairville Wash/Beam, iluminación arquitectónica ambiental y control DMX programado al ritmo de cada momento.',
      spec: 'Escenas programadas en Naranja Show, cian o ámbar cálido.', preset: 'premium', dm: 'amber', models: { heads: 1, bars: 1 } },
    { eyebrow: '03 · Vídeo, LED & Streaming', title: 'Pantallas LED, Tótems y Realización',
      body: 'Pantallas LED modulares de gran formato, tótems digitales 55" personalizables con tu marca, realización multicámara en directo y cobertura fotográfica profesional.',
      spec: 'Elige entre 3 kits de pantalla LED y añade tótems o pantallas de 55" con tu logo.', preset: 'integral', dm: 'corp', models: { led_m: 1, totem: 2 } }
  ];

  const state = {
    packMode: 'auto', pack: PACKS[0] ? PACKS[0].id : 0, guests: 100, hours: S.includedHours,
    space: 'Interior', zone: 'bcn', dm: 'dm', date: '', extras: {}, logo: null
  };
  EXTRAS.forEach(ex => { state.extras[ex.id] = 0; });

  const $ = id => document.getElementById(id);
  const esc = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const eur = cents => {
    const [i, d] = (cents / 100).toFixed(2).split('.');
    return i.replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ',' + d + ' €';
  };
  const eur0 = v => Math.round(v).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.') + ' €';

  function switchView(view, push = true) {
    const isQuoter = view === 'quoter';
    $('view-home').hidden = isQuoter;
    $('view-quoter').hidden = !isQuoter;
    $('nav-home').classList.toggle('active', !isQuoter);
    $('nav-quoter').classList.toggle('active', isQuoter);
    if (push) history.replaceState(null, '', isQuoter ? '#cotizador' : location.pathname);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    Stage.setActive(isQuoter);
    if (isQuoter) { Stage.init(); render(); }
  }

  function goHome(anchor) {
    if (!$('view-home').hidden && anchor) { $(anchor).scrollIntoView({ behavior: 'smooth' }); return false; }
    switchView('home');
    if (anchor) requestAnimationFrame(() => $(anchor).scrollIntoView({ behavior: 'smooth' }));
    return false;
  }

  function selectPillar(idx) {
    const p = PILLARS[idx];
    document.querySelectorAll('.pillar-tab').forEach((el, i) => {
      el.classList.toggle('active', i === idx);
      el.setAttribute('aria-selected', i === idx ? 'true' : 'false');
    });
    $('pp-eyebrow').textContent = p.eyebrow;
    $('pp-title').textContent = p.title;
    $('pp-body').textContent = p.body;
    $('pp-spec').textContent = p.spec;
    $('pp-btn').onclick = () => openQuoterWithPreset(idx);
  }

  function openQuoterWithPreset(idx) {
    const p = PILLARS[idx];
    const pack = PACKS.find(x => x.preset === p.preset);
    state.packMode = pack ? String(pack.id) : 'auto';
    state.dm = p.dm;
    EXTRAS.forEach(ex => { state.extras[ex.id] = 0; });
    Object.keys(p.models).forEach(model => {
      const ex = EXTRAS.find(x => x.model === model);
      if (ex) state.extras[ex.id] = Math.min(ex.max, p.models[model]);
    });
    syncInputs();
    switchView('quoter');
  }

  /* Configuración que llega del asistente de chat: pack, extras y aforo. */
  function applyConfig(cfg) {
    if (!cfg) return;
    const pk = packById(cfg.pack);
    state.packMode = pk ? String(pk.id) : 'auto';
    if (cfg.asistentes) state.guests = Math.max(30, Math.min(300, Math.round(Number(cfg.asistentes) / 10) * 10 || 100));
    EXTRAS.forEach(ex => { state.extras[ex.id] = 0; });
    let led = false;
    (cfg.extras || []).forEach(e => {
      const ex = EXTRAS.find(x => x.id === Number(e.id));
      if (!ex) return;
      if (isLed(ex)) { if (led) return; led = true; state.extras[ex.id] = 1; return; }
      state.extras[ex.id] = Math.max(0, Math.min(ex.max, Number(e.cantidad) || 1));
    });
    syncInputs();
    switchView('quoter');
  }

  function openQuoterWithPack(id) {
    const pk = packById(id);
    if (!pk) return;
    state.packMode = String(pk.id);
    if (pk.max !== null && (state.guests < pk.min || state.guests > pk.max)) state.guests = Math.max(30, Math.round((pk.min + pk.max) / 20) * 10);
    syncInputs();
    switchView('quoter');
  }

  function recommendPack(guests) {
    const fit = PACKS.find(p => guests >= p.min && (p.max === null || guests <= p.max));
    if (fit) return fit.id;
    const open = PACKS.find(p => p.max === null);
    return (open || PACKS[PACKS.length - 1] || {}).id;
  }

  function syncInputs() {
    $('guests-range').value = state.guests;
    $('pack-select').value = state.packMode;
    $('dm-select').value = state.dm;
    $('hours-select').value = String(state.hours);
  }

  function buildSelects() {
    $('pack-select').innerHTML = '<option value="auto">Automático según aforo</option>' + PACKS.map(p =>
      `<option value="${p.id}">${esc(p.name)} · ${p.from ? 'desde ' : ''}${eur0(p.price)}</option>`).join('');
    const h = S.includedHours, opts = [h, h + 1, h + 2, h + 3, h + 4, h + 6].filter(x => x <= 24);
    $('hours-select').innerHTML = opts.map(x => `<option value="${x}">${x} horas ${x === h ? '(incluidas)' : '(+' + eur0((x - h) * S.extraHour) + ')'}</option>`).join('');
  }

  function extraRow(ex) {
    const label = esc(ex.name);
    const thumb = ex.img
      ? `<button type="button" class="extra-photo" data-photo="${ex.id}" aria-label="Ver foto de ${label}"><img src="${esc(ex.img)}" alt="" loading="lazy" /></button>`
      : `<div class="extra-ico"><svg viewBox="0 0 24 24" aria-hidden="true">${ICONS[ex.model] || ICONS['']}</svg></div>`;
    return `
      <div class="extra-row" id="row-${ex.id}">
        <div class="extra-meta">
          ${thumb}
          <div>
            <div style="font-weight:600;font-size:13.5px;">${label}</div>
            <div style="font-size:12px;color:var(--gray);">${priceTxt(ex.price, ex.max)}</div>
          </div>
        </div>
        <div class="qty-ctl">
          <button type="button" data-id="${ex.id}" data-d="-1" aria-label="Quitar ${label}">−</button>
          <output id="qty-${ex.id}" aria-live="polite">0</output>
          <button type="button" data-id="${ex.id}" data-d="1" aria-label="Añadir ${label}">+</button>
        </div>
      </div>`;
  }

  function ledRow() {
    if (!LEDS.length) return '';
    return `
      <div class="extra-row extra-choice" id="row-led">
        <div class="extra-meta">
          <div class="extra-ico"><svg viewBox="0 0 24 24" aria-hidden="true">${ICONS.led}</svg></div>
          <div>
            <div style="font-weight:600;font-size:13.5px;">Pantalla LED</div>
            <div style="font-size:12px;color:var(--gray);" id="sub-led">Elige un kit</div>
          </div>
        </div>
        <div class="seg" role="radiogroup" aria-label="Pantalla LED">
          <button type="button" role="radio" data-led="">Ninguna</button>
          ${LEDS.map(ex => `<button type="button" role="radio" data-led="${ex.id}" title="${esc(ex.name)}">${esc(ex.name.replace(/^Pantalla LED\s*/i, '').split('·')[0].trim())}<small>${esc((ex.name.split('·')[1] || '').trim())}</small></button>`).join('')}
        </div>
      </div>`;
  }

  function buildExtrasList() {
    if (!EXTRAS.length) { $('extras-list').innerHTML = '<p class="msg">No hay extras publicados.</p>'; return; }
    $('extras-list').innerHTML = ledRow() + tarimaRow() + EXTRAS.filter(ex => !isSpecial(ex)).map(extraRow).join('');
    $('extras-list').addEventListener('click', e => {
      const ph = e.target.closest('[data-photo]');
      if (ph) { openPhoto(EXTRAS.find(x => x.id === Number(ph.dataset.photo))); return; }
      const tb = e.target.closest('button[data-tarima]');
      if (tb) {
        if (tb.dataset.tarima === 'edit') { editTarima(); return; }
        setTarimaOn(tb.dataset.tarima === '1'); return;
      }
      const l = e.target.closest('button[data-led]');
      if (l) { LEDS.forEach(ex => { state.extras[ex.id] = String(ex.id) === l.dataset.led ? 1 : 0; }); render(); return; }
      const b = e.target.closest('button[data-id]');
      if (!b) return;
      const ex = EXTRAS.find(x => x.id === Number(b.dataset.id));
      state.extras[ex.id] = Math.max(0, Math.min(ex.max, state.extras[ex.id] + Number(b.dataset.d)));
      render();
    });
  }

  function tarimaRow() {
    if (!TARIMA) return '';
    return `
      <div class="extra-row extra-choice" id="row-tarima">
        <div class="extra-meta">
          <div class="extra-ico"><svg viewBox="0 0 24 24" aria-hidden="true">${ICONS.tarima}</svg></div>
          <div>
            <div style="font-weight:600;font-size:13.5px;">${esc(TARIMA.name)}</div>
            <div style="font-size:12px;color:var(--gray);" id="sub-tarima"></div>
          </div>
        </div>
        <div class="seg" role="radiogroup" aria-label="Tarima">
          <button type="button" role="radio" data-tarima="0">Sin tarima</button>
          <button type="button" role="radio" data-tarima="1">Con tarima</button>
          <button type="button" data-tarima="edit">Medidas</button>
        </div>
      </div>`;
  }
  function syncTarima() {
    if (!TARIMA) return;
    if (state.extras[TARIMA.id] > 0) state.extras[TARIMA.id] = Math.min(TARIMA.max, tarimaM2(Stage.tarima()));
  }
  function setTarimaOn(on) { if (TARIMA) state.extras[TARIMA.id] = on ? 1 : 0; render(); }
  function editTarima() {
    if (!(state.extras[TARIMA.id] > 0)) setTarimaOn(true);
    $('canvas-3d').scrollIntoView({ behavior: 'smooth', block: 'center' });
    Stage.select('tarima');
  }

  function openPhoto(ex) {
    const dlg = $('photo-dialog');
    if (!ex || !dlg || typeof dlg.showModal !== 'function') return;
    $('photo-dialog-img').src = ex.photo || ex.img;
    $('photo-dialog-img').alt = ex.name;
    $('photo-dialog-cap').textContent = ex.name + (ex.desc ? ' · ' + ex.desc : '');
    dlg.showModal();
  }

  function readInputs() {
    state.guests = parseInt($('guests-range').value, 10) || 100;
    state.packMode = $('pack-select').value;
    state.hours = parseInt($('hours-select').value, 10) || S.includedHours;
    state.space = $('space-select').value;
    state.zone = $('zone-select').value;
    state.dm = $('dm-select').value;
    state.date = $('date-input').value;
  }

  function modelCounts() {
    const m = {};
    EXTRAS.forEach(ex => { if (ex.model && state.extras[ex.id]) m[ex.model] = (m[ex.model] || 0) + state.extras[ex.id]; });
    return m;
  }

  function computeQuote() {
    const pack = packById(state.pack);
    const lines = [];
    if (pack) lines.push({ label: `Pack ${pack.name}${pack.from ? ' (desde)' : ''}`, cents: Math.round(pack.price * 100) });
    const extraHours = Math.max(0, state.hours - S.includedHours);
    if (extraHours) lines.push({ label: `Horas extra (${extraHours} × ${eur0(S.extraHour)})`, cents: extraHours * Math.round(S.extraHour * 100) });
    EXTRAS.forEach(ex => {
      const q = state.extras[ex.id];
      if (!q) return;
      if (ex.model === 'led_s' && pack && pack.preset === 'integral') { lines.push({ label: `${ex.name} (incluida en el pack)`, cents: 0 }); return; }
      if (ex === TARIMA) { const t = Stage.tarima(); lines.push({ label: `Tarima ${dec(t.w)} × ${dec(t.d)} m (${q} m²) · ${dec(t.h)} m de alto`, cents: ex.price === null ? null : q * Math.round(ex.price * 100) }); return; }
      lines.push({ label: `${ex.name}${q > 1 ? ' × ' + q : ''}`, cents: ex.price === null ? null : q * Math.round(ex.price * 100) });
    });
    const pending = lines.filter(l => l.cents === null).length;
    const base = lines.reduce((a, l) => a + (l.cents || 0), 0);
    const iva = Math.round(base * S.iva / 100);
    const total = base + iva;
    return { pack, lines, pending, base, iva, total, deposit: Math.round(total * S.deposit / 100) };
  }

  function fmtDate(v) {
    if (!v) return 'fecha por confirmar';
    return new Date(v + 'T12:00').toLocaleDateString('es-ES', { day: 'numeric', month: 'long', year: 'numeric' });
  }

  const ZONES = { bcn: 'Barcelona ciudad', amb: 'Área metropolitana (desplazamiento a confirmar)', cat: 'Resto de Cataluña (desplazamiento a confirmar)' };

  function render() {
    readInputs();
    syncTarima();
    state.pack = state.packMode === 'auto' ? recommendPack(state.guests) : Number(state.packMode);
    $('guests-val').textContent = state.guests >= 300 ? '300+' : state.guests;
    $('space-note').textContent = state.space === 'Exterior'
      ? 'Exterior: revisamos protección contra lluvia y viento, lastres, punto de corriente y normativa del recinto antes del montaje.'
      : 'Interior: configuración acústica y lumínica adaptada a sala, hotel o local.';

    if (TARIMA) {
      const t = Stage.tarima(), on = state.extras[TARIMA.id] > 0;
      $('row-tarima').classList.toggle('on', on);
      $('row-tarima').querySelectorAll('[data-tarima="0"],[data-tarima="1"]').forEach(b => b.setAttribute('aria-checked', (b.dataset.tarima === '1') === on ? 'true' : 'false'));
      $('sub-tarima').textContent = `${dec(t.w)} × ${dec(t.d)} m · ${tarimaM2(t)} m² · ${dec(t.h)} m de alto · ` + (TARIMA.price === null ? 'a consultar' : '+' + eur0(TARIMA.price) + '/m²');
    }
    EXTRAS.filter(ex => !isSpecial(ex)).forEach(ex => {
      $('qty-' + ex.id).textContent = state.extras[ex.id];
      $('row-' + ex.id).classList.toggle('on', state.extras[ex.id] > 0);
    });
    if (LEDS.length) {
      const chosen = LEDS.find(ex => state.extras[ex.id]);
      $('row-led').classList.toggle('on', !!chosen);
      $('row-led').querySelectorAll('[data-led]').forEach(b => b.setAttribute('aria-checked', b.dataset.led === (chosen ? String(chosen.id) : '') ? 'true' : 'false'));
      const pk0 = packById(state.pack);
      $('sub-led').textContent = chosen ? (chosen.model === 'led_s' && pk0 && pk0.preset === 'integral' ? 'Incluida en el pack' : priceTxt(chosen.price, 1)) : (pk0 && pk0.preset === 'integral' ? 'Kit S incluido en el pack' : 'Elige un kit');
    }
    const models = modelCounts();
    $('logo-panel').hidden = !(models.totem || models.screen55);

    const q = computeQuote();
    const pk = q.pack;
    $('pack-badge').textContent = pk ? `Pack ${pk.name} (${pk.max === null ? 'a medida' : pk.min + '–' + pk.max + ' pers.'})` : 'Sin packs publicados';
    $('quote-total').textContent = eur(q.total);
    $('quote-deposit').textContent = eur(q.deposit);
    $('dep-pct').textContent = S.deposit;
    $('reserve-amount').textContent = eur(q.deposit);

    const rec = recommendPack(state.guests);
    const hint = $('pack-hint');
    if (pk && state.packMode !== 'auto' && rec !== pk.id && pk.max !== null && (state.guests < pk.min || state.guests > pk.max)) {
      hint.hidden = false;
      hint.textContent = `Para ${state.guests} personas recomendamos el Pack ${packById(rec).name}.`;
    } else hint.hidden = true;

    const linesHtml = q.lines.map(l => `<div class="line-item"><span>${esc(l.label)}</span><strong>${l.cents === null ? 'A consultar' : eur(l.cents)}</strong></div>`).join('')
      + `<div class="line-item"><span>Base imponible</span><strong>${eur(q.base)}</strong></div>`
      + `<div class="line-item"><span>IVA ${S.iva} %</span><strong>${eur(q.iva)}</strong></div>`
      + `<div class="line-item sum"><span>Reserva ${S.deposit} % · resto antes del evento</span><strong>${eur(q.deposit)}</strong></div>`
      + (q.pending ? `<p class="msg">${q.pending === 1 ? '1 concepto se presupuesta aparte y no está' : q.pending + ' conceptos se presupuestan aparte y no están'} en el total.</p>` : '');
    $('quote-lines').innerHTML = linesHtml;
    $('prop-lines').innerHTML = linesHtml;

    const name = $('client-name').value.trim() || 'Cliente';
    $('prop-ref').textContent = 'MSB-' + new Date().toISOString().slice(0, 10).replace(/-/g, '');
    $('prop-title').textContent = pk ? `Pack ${pk.name}` : '';
    $('prop-total').textContent = eur(q.total);
    $('prop-meta').textContent = `${name} · ${fmtDate(state.date)} · ${state.guests} personas · ${state.hours} h · ${state.space} · ${ZONES[state.zone]}`;

    const phone = $('client-phone').value.trim();
    const wa = [
      `Hola Media Show BCN, soy ${name}${phone ? ' (' + phone + ')' : ''}.`,
      pk ? `Quiero reservar: Pack ${pk.name}${pk.from ? ' (desde)' : ''}.` : 'Quiero un presupuesto.',
      `Fecha: ${fmtDate(state.date)} · ${state.guests} personas · ${state.hours} h · ${state.space} · ${ZONES[state.zone]}.`,
      `Iluminación: ${$('dm-select').selectedOptions[0].text}.`
    ];
    const sizes = Stage.describe();
    if (sizes.length) wa.push('Medidas en el render: ' + sizes.join('; ') + '.');
    $('prop-sizes').hidden = !sizes.length;
    $('prop-sizes').textContent = sizes.length ? 'Medidas en el render: ' + sizes.join('; ') + '. Precio a confirmar.' : '';
    const extrasTxt = q.lines.slice(1).filter(l => !/^Horas extra/.test(l.label)).map(l => l.label + (l.cents === null ? ' (a consultar)' : ''));
    if (extrasTxt.length) wa.push('Extras: ' + extrasTxt.join(', ') + '.');
    if ((models.totem || models.screen55) && state.logo) wa.push('Tengo logo para las pantallas; os lo envío por aquí.');
    wa.push(`Estimado con IVA: ${eur(q.total)} (reserva ${S.deposit} %: ${eur(q.deposit)})${q.pending ? ' + conceptos a consultar' : ''}.`);
    $('wa-quote-btn').href = `https://wa.me/${S.whatsapp}?text=${encodeURIComponent(wa.join('\n'))}`;
    const ok = $('consent-check').checked;
    $('wa-quote-btn').setAttribute('aria-disabled', ok ? 'false' : 'true');
    $('reserve-btn').hidden = !(D.shop && pk);
    $('reserve-btn').setAttribute('aria-disabled', ok ? 'false' : 'true');

    Stage.update({ preset: pk ? pk.preset : 'corporate', models, dm: state.dm, guests: state.guests, tarimaKnown: !!TARIMA });
  }

  function toggleProposal() {
    const open = $('proposal-box').classList.toggle('open');
    $('proposal-toggle').textContent = open ? 'Ocultar propuesta' : 'Ver propuesta oficial';
    if (open) $('proposal-box').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function printProposal() {
    $('proposal-box').classList.add('open');
    window.print();
  }

  /* Logo del cliente: se ve en el 3D y se adjunta a la reserva como PNG. */
  const PLACEHOLDER = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#A6A49E" stroke-width="1.6"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="M21 17l-5-5-8 8"/></svg>';
  function setupLogo() {
    const input = $('logo-input'), msg = $('logo-msg');
    $('logo-thumb').innerHTML = PLACEHOLDER;
    input.addEventListener('change', () => {
      const file = input.files && input.files[0];
      input.value = '';
      if (!file) return;
      msg.classList.remove('err');
      if (!/^image\/(png|jpeg|svg\+xml|webp)$/.test(file.type)) { msg.classList.add('err'); msg.textContent = 'Formato no válido. Sube un archivo PNG, SVG, JPG o WebP.'; return; }
      if (file.size > 5 * 1024 * 1024) { msg.classList.add('err'); msg.textContent = 'El archivo pesa más de 5 MB. Reduce su tamaño y vuelve a subirlo.'; return; }
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => {
        if (state.logo) URL.revokeObjectURL(state.logo.src);
        state.logo = img;
        $('logo-thumb').innerHTML = '';
        $('logo-thumb').appendChild(img.cloneNode());
        $('prop-logo').src = url; $('prop-logo').hidden = false;
        $('logo-remove').hidden = false;
        msg.textContent = `Logo cargado: ${file.name}.`;
        Stage.setLogo(img);
        render();
      };
      img.onerror = () => { URL.revokeObjectURL(url); msg.classList.add('err'); msg.textContent = 'No se ha podido leer la imagen. Prueba con otro archivo.'; };
      img.src = url;
    });
    $('logo-remove').addEventListener('click', () => {
      if (state.logo) URL.revokeObjectURL(state.logo.src);
      state.logo = null;
      $('logo-thumb').innerHTML = PLACEHOLDER;
      $('prop-logo').hidden = true; $('prop-logo').removeAttribute('src');
      $('logo-remove').hidden = true;
      msg.textContent = 'Logo quitado.';
      Stage.setLogo(null);
      render();
    });
  }

  function logoBlob() {
    return new Promise(resolve => {
      const m = modelCounts();
      if (!state.logo || !(m.totem || m.screen55)) return resolve(null);
      const img = state.logo, r = Math.min(1, 1600 / Math.max(img.naturalWidth || 1, img.naturalHeight || 1));
      const c = document.createElement('canvas');
      c.width = Math.max(1, Math.round((img.naturalWidth || 800) * r));
      c.height = Math.max(1, Math.round((img.naturalHeight || 400) * r));
      try { c.getContext('2d').drawImage(img, 0, 0, c.width, c.height); c.toBlob(resolve, 'image/png'); }
      catch (e) { resolve(null); }
    });
  }

  async function reserve() {
    const btn = $('reserve-btn'), msg = $('wa-msg');
    if (!$('consent-check').checked) { msg.textContent = 'Marca la casilla de privacidad y condiciones para reservar.'; $('consent-check').focus(); return; }
    if (btn.dataset.busy) return;
    btn.dataset.busy = '1';
    msg.textContent = 'Preparando tu reserva…';
    const fd = new FormData();
    fd.append('action', 'msb_reserve');
    fd.append('nonce', D.nonce);
    fd.append('pack', state.pack);
    fd.append('hours', state.hours);
    fd.append('guests', state.guests);
    fd.append('date', state.date);
    fd.append('space', state.space);
    fd.append('zone', state.zone);
    fd.append('scene', $('dm-select').selectedOptions[0].text);
    fd.append('name', $('client-name').value.trim());
    fd.append('phone', $('client-phone').value.trim());
    fd.append('extras', JSON.stringify(state.extras));
    const sizes = Stage.describe();
    if (TARIMA && state.extras[TARIMA.id]) { const t = Stage.tarima(); sizes.unshift(`Tarima ${dec(t.w)} × ${dec(t.d)} m, ${dec(t.h)} m de alto`); }
    fd.append('montaje', sizes.join('; '));
    const blob = await logoBlob();
    if (blob) fd.append('logo', blob, 'logo.png');
    try {
      const res = await fetch(D.ajax, { method: 'POST', body: fd, credentials: 'same-origin' });
      const json = await res.json();
      if (json.success) { location.href = json.data.redirect; return; }
      msg.textContent = (json.data && json.data.message) || 'No se ha podido preparar la reserva. Inténtalo de nuevo o escríbenos por WhatsApp.';
    } catch (e) {
      msg.textContent = 'No hay conexión con la tienda. Revisa tu conexión o envíanos el resumen por WhatsApp.';
    }
    delete btn.dataset.busy;
  }

  /* Foto del espacio y exportación en 1080p */
  function download(blob, name) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  }
  function setupExport() {
    const msg = $('export-msg'), input = $('venue-input');
    let venueUrl = null;
    input.addEventListener('change', () => {
      const file = input.files && input.files[0];
      input.value = '';
      if (!file) return;
      if (!/^image\/(png|jpeg|webp)$/.test(file.type) || file.size > 15 * 1024 * 1024) { msg.textContent = 'Sube una foto JPG, PNG o WebP de hasta 15 MB.'; return; }
      const img = new Image();
      img.onload = () => {
        if (venueUrl) URL.revokeObjectURL(venueUrl);
        venueUrl = img.src;
        Stage.setVenue(img);
        $('venue-remove').hidden = false;
        $('fit-panel').hidden = false;
        syncView();
        msg.textContent = 'Foto cargada. Encaja la cámara con los controles de abajo y toca cada equipo para ajustar su tamaño.';
      };
      img.onerror = () => { msg.textContent = 'No se ha podido leer la foto. Prueba con otra.'; };
      img.src = URL.createObjectURL(file);
    });
    $('venue-remove').addEventListener('click', () => {
      Stage.setVenue(null);
      if (venueUrl) URL.revokeObjectURL(venueUrl);
      venueUrl = null;
      $('venue-remove').hidden = true;
      $('fit-panel').hidden = true;
      Stage.setView({ tarima: true });
      msg.textContent = 'Foto quitada.';
    });
    $('shot-btn').addEventListener('click', async () => {
      const o = exportOpts();
      try { download(await Stage.snapshot(o), `mediashowbcn-propuesta-${o.h}p.png`); msg.textContent = `Imagen ${o.label} descargada.`; }
      catch (e) { msg.textContent = e.message; }
    });
    $('video-btn').addEventListener('click', async () => {
      if (Stage.recording) return;
      const btn = $('video-btn');
      btn.setAttribute('aria-disabled', 'true');
      const o = exportOpts();
      msg.textContent = `Grabando 10 segundos en ${o.label}… no cambies de pestaña.`;
      try {
        const { blob, ext } = await Stage.record(10, o);
        download(blob, `mediashowbcn-propuesta-${o.h}p.` + ext);
        msg.textContent = `Vídeo ${o.label} descargado (${ext.toUpperCase()}).`;
      } catch (e) { msg.textContent = e.message; }
      btn.removeAttribute('aria-disabled');
    });
  }

  const RES = { '1080': { w: 1920, h: 1080, label: '1080p' }, '1440': { w: 2560, h: 1440, label: '1440p' }, '2160': { w: 3840, h: 2160, label: '4K' } };
  function exportOpts() {
    const r = RES[S.pro && $('export-res') ? $('export-res').value : '1080'] || RES['1080'];
    return Object.assign({ mark: !(S.pro && $('export-mark') && !$('export-mark').checked) }, r);
  }

  /* Encaje de la cámara con la foto del espacio */
  const FIT = { height: ['fit-height', 1, ' m'], dist: ['fit-dist', 1, ' m'], fov: ['fit-fov', 0, '°'], aim: ['fit-aim', 1, ' m'], shadow: ['fit-shadow', 0, ' %'], light: ['fit-light', 0, ' %'], warm: ['fit-warm', 0, ''], dir: ['fit-dir', 0, '°'] };
  const PCT = { shadow: 1, light: 1 };
  function syncView() {
    const v = Stage.getView();
    if (!v) return;
    Object.keys(FIT).forEach(k => {
      const [id, d, u] = FIT[k];
      $(id).value = v[k];
      $(id + '-val').textContent = PCT[k] ? Math.round(v[k] * 100) + u : k === 'warm' ? (v[k] > 0.05 ? 'cálida' : v[k] < -0.05 ? 'fría' : 'neutra') : Number(v[k]).toFixed(d).replace('.', ',') + u;
    });
    $('fit-grid').checked = v.grid;
  }
  function setupFit() {
    Object.keys(FIT).forEach(k => $(FIT[k][0]).addEventListener('input', e => { Stage.setView({ [k]: Number(e.target.value) }); syncView(); }));
    $('fit-grid').addEventListener('change', e => Stage.setView({ grid: e.target.checked }));
    window.addEventListener('msb:camera', () => { if (!$('fit-panel').hidden) syncView(); });
  }

  /* Panel del equipo tocado: tamaño, pulgadas, medidas de la pantalla LED, altura y giro */
  const num = v => String(+Number(v).toFixed(2)).replace('.', ',');
  function showInspector(d) {
    $('insp').hidden = !d;
    if (!d) return;
    $('insp-title').textContent = d.label;
    const tar = d.kind === 'tarima';
    $('insp-tarima-row').hidden = !tar;
    $('insp-lift-row').hidden = tar;
    $('insp-rot').hidden = tar;
    $('insp-real').hidden = !d.real;
    if (tar) {
      $('insp-inch-row').hidden = true; $('insp-dims-row').hidden = true; $('insp-size-row').hidden = true;
      $('insp-tw').value = d.tarima.w; $('insp-td').value = d.tarima.d; $('insp-th').value = d.tarima.h;
      $('insp-tm2').textContent = dec(d.tarima.w * d.tarima.d) + ' m²';
      return;
    }
    const inch = d.kind === 'screen' || d.kind === 'totem', wall = d.kind === 'wall';
    $('insp-inch-row').hidden = !inch;
    $('insp-dims-row').hidden = !wall;
    $('insp-size-row').hidden = inch || wall;
    $('insp-size').value = Math.round(d.size * 100);
    $('insp-size-val').textContent = Math.round(d.size * 100) + ' %';
    if (inch) $('insp-inch').value = String(d.inch);
    if (wall) { $('insp-w').value = d.dims[0]; $('insp-h').value = d.dims[1]; $('insp-m2').textContent = num(d.dims[0] * d.dims[1]) + ' m²'; }
    $('insp-lift').value = Math.round(d.lift * 100);
    $('insp-lift-val').textContent = num(d.lift) + ' m';
  }
  function setupInspector() {
    window.addEventListener('msb:select', e => showInspector(e.detail));
    window.addEventListener('msb:montage', () => { syncTarima(); render(); });
    const tdims = () => {
      const r = v => Math.round(Number(v) * 10) / 10;
      set('tarima', { w: r($('insp-tw').value), d: r($('insp-td').value), h: r($('insp-th').value) });
    };
    ['insp-tw', 'insp-td', 'insp-th'].forEach(id => $(id).addEventListener('change', tdims));
    const set = (p, v) => showInspector(Stage.adjust(p, v));
    $('insp-size').addEventListener('input', e => set('size', e.target.value / 100));
    $('insp-inch').addEventListener('change', e => set('inch', Number(e.target.value)));
    $('insp-lift').addEventListener('input', e => set('lift', e.target.value / 100));
    const dims = () => {
      const w = Math.round(Number($('insp-w').value) * 2) / 2, h = Math.round(Number($('insp-h').value) * 2) / 2;
      if (w >= 1 && h >= 0.5) set('dims', [w, h]);
    };
    $('insp-w').addEventListener('change', dims);
    $('insp-h').addEventListener('change', dims);
    $('insp').addEventListener('click', e => { const r = e.target.closest('[data-rot]'); if (r) set('rot', Number(r.dataset.rot)); });
    $('insp-reset').addEventListener('click', () => set('reset'));
    $('insp-close').addEventListener('click', () => Stage.select(null));
  }


  /* Botones para sumar equipos desde el propio render (suman también al presupuesto). */
  const ADD = [['spk', '+ Altavoz'], ['heads', '+ 6 cabezas'], ['bars', '+ 4 barras'], ['totem', '+ Tótem'], ['screen55', '+ Pantalla'], ['mic', '+ Micro'], ['tarima', '+ Tarima']];
  function setupAddBar() {
    const bar = $('add-bar');
    const items = ADD.map(([m, label]) => [EXTRAS.find(ex => ex.model === m), label]).filter(x => x[0]);
    if (!items.length) { bar.hidden = true; return; }
    bar.innerHTML = '<span>Añadir al render:</span>' + items.map(([ex, label]) => `<button type="button" class="btn btn-sm" data-add="${ex.id}">${esc(label)}</button>`).join('');
    bar.addEventListener('click', e => {
      const b = e.target.closest('[data-add]');
      if (!b) return;
      const ex = EXTRAS.find(x => x.id === Number(b.dataset.add));
      if (ex === TARIMA) { editTarima(); render(); return; }
      if (state.extras[ex.id] >= ex.max) { $('export-msg').textContent = `Máximo ${ex.max} de ${ex.name}.`; return; }
      state.extras[ex.id]++;
      render();
    });
  }

  /* Integración con la foto: calibración con 4 esquinas, primer plano y luz */
  function setupIntegrate() {
    const msg = $('cal-msg');
    const STEPS = ['1 · fondo izquierda', '2 · fondo derecha', '3 · delante derecha', '4 · delante izquierda'];
    $('cal-btn').addEventListener('click', () => {
      const w = Number($('cal-w').value), d = Number($('cal-d').value);
      if (!(w > 0.2 && d > 0.2)) { msg.textContent = 'Escribe el ancho y el fondo del rectángulo en metros.'; return; }
      setPaint(null);
      fold('Marcando esquinas… (toca aquí para cancelar)');
      $('canvas-3d').scrollIntoView({ behavior: 'smooth', block: 'center' });
      Stage.calibrate(w, d);
    });
    window.addEventListener('msb:calib', e => {
      const d = e.detail;
      if (!d.done) { msg.textContent = 'Toca en la foto la esquina ' + STEPS[d.step] + '.'; $('fit-sum').textContent = 'Toca la esquina ' + STEPS[d.step] + ' (aquí para cancelar)'; return; }
      unfold();
      msg.textContent = d.ok
        ? `Listo: cámara a ${String(d.height).replace('.', ',')} m de altura y lente de ${d.fov}°${d.estimated ? '' : ' (foto muy frontal: si no encaja, cambia la lente y repite)'}. Los equipos ya están a escala real.`
        : d.msg;
      syncView();
    });
    const panel = $('fit-panel'), sum = $('fit-sum'), title = sum.textContent;
    let folded = false;
    function fold(label) { folded = true; panel.open = false; sum.textContent = label; }
    function unfold() { folded = false; sum.textContent = title; panel.open = true; }
    panel.addEventListener('toggle', () => {
      if (!panel.open || !folded) return;
      Stage.cancelCalib(); setPaint(null); unfold();
      if (/Toca|Marcando/.test(msg.textContent)) msg.textContent = 'Calibración cancelada.';
    });
    const setPaint = mode => {
      Stage.paint(mode);
      if (mode) fold(mode === 'paint' ? '✓ Terminar de pintar' : '✓ Terminar de borrar');
      $('fg-paint').setAttribute('aria-pressed', mode === 'paint' ? 'true' : 'false');
      $('fg-erase').setAttribute('aria-pressed', mode === 'erase' ? 'true' : 'false');
    };
    $('fg-paint').addEventListener('click', () => setPaint($('fg-paint').getAttribute('aria-pressed') === 'true' ? null : 'paint'));
    $('fg-erase').addEventListener('click', () => setPaint($('fg-erase').getAttribute('aria-pressed') === 'true' ? null : 'erase'));
    $('fg-clear').addEventListener('click', () => Stage.clearFg());
    $('fg-brush').addEventListener('input', e => Stage.brush(Number(e.target.value)));
    $('look-auto').addEventListener('click', () => { Stage.autoLook(); syncView(); });
    $('venue-remove').addEventListener('click', () => { setPaint(null); msg.textContent = ''; });
  }
/* ===================== ESCENARIO 3D (Three.js r128) ===================== */
const Stage = (() => {
  let inited = false, active = false, failed = false;
  let scene, camera, renderer, controls, clock;
  let lights = {}, rig = {}, tex = {};
  const PAL = {
    dm:    { a: 0xe65837, b: 0x22d3ee, rim: 0xe65837, label: 'Show Naranja & Cian' },
    amber: { a: 0xffb347, b: 0xe65837, rim: 0xf59e0b, label: 'Gala Ámbar Cálido' },
    corp:  { a: 0xf1f5f9, b: 0xa5c8ff, rim: 0xe2e8f0, label: 'Corporativo Limpio' }
  };
  let pal = PAL.dm, mode = 'dm';
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const geoCache = {};
  const cyl = r => geoCache['c' + r] || (geoCache['c' + r] = new THREE.CylinderGeometry(r, r, 1, 6));

  function strut(a, b, r, mat, parent) {
    const d = new THREE.Vector3().subVectors(b, a);
    const len = d.length();
    const m = new THREE.Mesh(cyl(r), mat);
    m.scale.set(1, len, 1);
    m.position.copy(a).addScaledVector(d, 0.5);
    m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.normalize());
    parent.add(m);
  }

  // Truss cuadrado de 29 cm con cordones y diagonales en zigzag
  function trussRun(p0, p1, mat, parent, s = 0.29) {
    const dir = new THREE.Vector3().subVectors(p1, p0);
    const L = dir.length(); dir.normalize();
    const ref = Math.abs(dir.y) > 0.9 ? new THREE.Vector3(1, 0, 0) : new THREE.Vector3(0, 1, 0);
    const u = new THREE.Vector3().crossVectors(dir, ref).normalize();
    const v = new THREE.Vector3().crossVectors(dir, u).normalize();
    const h = s / 2, offs = [[-h, -h], [h, -h], [h, h], [-h, h]];
    const c = (t, i) => p0.clone().addScaledVector(dir, t).addScaledVector(u, offs[i][0]).addScaledVector(v, offs[i][1]);
    for (let i = 0; i < 4; i++) strut(c(0, i), c(L, i), 0.024, mat, parent);
    const n = Math.max(1, Math.round(L / s));
    for (let f = 0; f < 4; f++) {
      const j = (f + 1) % 4;
      for (let k = 0; k < n; k++) {
        const t0 = k * L / n, t1 = (k + 1) * L / n;
        if (k % 2) strut(c(t0, j), c(t1, f), 0.011, mat, parent); else strut(c(t0, f), c(t1, j), 0.011, mat, parent);
      }
    }
  }

  function canvasTex(w, h, draw) {
    const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
    draw(cv.getContext('2d'), w, h);
    const t = new THREE.CanvasTexture(cv);
    t.anisotropy = 4;
    return t;
  }

  function makeTextures() {
    tex.grille = canvasTex(128, 128, (g, w, h) => {
      g.fillStyle = '#202226'; g.fillRect(0, 0, w, h);
      g.fillStyle = '#08090a';
      for (let y = 4; y < h; y += 8) for (let x = (y / 8) % 2 ? 8 : 4; x < w; x += 8) { g.beginPath(); g.arc(x, y, 2.2, 0, 6.3); g.fill(); }
    });
    tex.grille.wrapS = tex.grille.wrapT = THREE.RepeatWrapping;
    tex.rcf = canvasTex(256, 96, (g, w, h) => {
      g.fillStyle = '#16171a'; g.fillRect(0, 0, w, h);
      g.fillStyle = '#f4f4f4'; g.font = 'bold 64px Arial, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
      g.fillText('RCF', w / 2, h / 2 + 4);
    });
    tex.alto = canvasTex(256, 96, (g, w, h) => {
      g.fillStyle = '#121316'; g.fillRect(0, 0, w, h);
      g.fillStyle = '#e8e8e8'; g.font = 'bold 60px Arial, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
      g.fillText('ALTO', w / 2, h / 2 + 3);
    });
    tex.beam = canvasTex(4, 256, (g, w, h) => {
      const gr = g.createLinearGradient(0, 0, 0, h);
      gr.addColorStop(0, '#ffffff'); gr.addColorStop(0.45, '#555555'); gr.addColorStop(1, '#000000');
      g.fillStyle = gr; g.fillRect(0, 0, w, h);
    });
    tex.drape = canvasTex(256, 64, (g, w, h) => {
      for (let x = 0; x < w; x++) { const s = 18 + 10 * Math.sin(x / 7); g.fillStyle = `rgb(${s},${s},${s + 2})`; g.fillRect(x, 0, 1, h); }
    });
    tex.drape.wrapS = THREE.RepeatWrapping; tex.drape.repeat.set(10, 1);
    tex.puff = canvasTex(64, 64, (g, w, h) => {
      const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
      gr.addColorStop(0, 'rgba(255,255,255,.55)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
      g.fillStyle = gr; g.fillRect(0, 0, w, h);
    });
    tex.totemCanvas = document.createElement('canvas'); tex.totemCanvas.width = 540; tex.totemCanvas.height = 960;
    tex.totem = new THREE.CanvasTexture(tex.totemCanvas);
    tex.ledCanvas = document.createElement('canvas'); tex.ledCanvas.width = 640; tex.ledCanvas.height = 480;
    tex.led = new THREE.CanvasTexture(tex.ledCanvas);
  }

  function drawContain(g, img, x, y, w, h) {
    const r = Math.min(w / img.width, h / img.height);
    const dw = img.width * r, dh = img.height * r;
    g.drawImage(img, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh);
  }

  function drawBrand(g, cx, cy, size) {
    g.save();
    g.strokeStyle = '#E65837'; g.lineWidth = size * 0.06; g.lineCap = 'round'; g.lineJoin = 'round';
    g.translate(cx - size * 0.5, cy - size * 0.95); g.scale(size / 40, size / 40);
    g.beginPath(); g.moveTo(3, 23); g.lineTo(11, 6); g.quadraticCurveTo(14, 2, 16.5, 6.8); g.lineTo(18.5, 19.5);
    g.quadraticCurveTo(20, 23.5, 24, 20.1); g.lineTo(29, 8.5); g.quadraticCurveTo(32, 4.5, 35, 9.2); g.lineTo(37, 19);
    g.lineWidth = 3.6; g.stroke(); g.restore();
    g.textAlign = 'center'; g.textBaseline = 'alphabetic';
    g.fillStyle = '#FFFFFF'; fitText(g, 'MEDIA SHOW', cx, cy + size * 0.2, size * 0.36, size * 1.6);
    g.fillStyle = '#E65837'; fitText(g, 'BCN', cx, cy + size * 0.78, size * 0.6, size * 1.6);
  }

  function fitText(g, text, x, y, px, maxW) {
    g.font = `${px}px "Bebas Neue", Impact, sans-serif`;
    const w = g.measureText(text).width;
    if (w > maxW) g.font = `${px * maxW / w}px "Bebas Neue", Impact, sans-serif`;
    g.fillText(text, x, y);
  }

  let logoImg = null;
  function drawTotem() {
    const g = tex.totemCanvas.getContext('2d'), w = 540, h = 960;
    const bg = g.createLinearGradient(0, 0, 0, h);
    bg.addColorStop(0, '#141414'); bg.addColorStop(1, '#050505');
    g.fillStyle = bg; g.fillRect(0, 0, w, h);
    try {
      if (logoImg) drawContain(g, logoImg, 50, 170, w - 100, 520);
      else drawBrand(g, w / 2, 400, 300);
    } catch (e) { drawBrand(g, w / 2, 400, 300); }
    g.fillStyle = '#E65837'; g.fillRect(0, h - 120, w, 120);
    g.fillStyle = '#0A0A0A'; g.textAlign = 'center';
    fitText(g, logoImg ? 'BIENVENIDOS' : 'MEDIASHOWBCN.COM', w / 2, h - 42, 56, w - 60);
    tex.totem.needsUpdate = true;
  }

  function drawLed(t) {
    const g = tex.ledCanvas.getContext('2d'), w = 640, h = 480;
    const ca = new THREE.Color(pal.a), cb = new THREE.Color(pal.b);
    const k = (Math.sin(t * 0.6) + 1) / 2;
    const gr = g.createLinearGradient(0, 0, w, h);
    gr.addColorStop(0, '#' + ca.clone().multiplyScalar(0.55 + 0.45 * k).getHexString());
    gr.addColorStop(1, '#' + cb.clone().multiplyScalar(0.35 + 0.4 * (1 - k)).getHexString());
    g.fillStyle = gr; g.fillRect(0, 0, w, h);
    g.fillStyle = 'rgba(0,0,0,.35)'; g.fillRect(0, 0, w, h);
    try {
      if (logoImg) drawContain(g, logoImg, 120, 110, 400, 260);
      else drawBrand(g, w / 2, 250, 230);
    } catch (e) { drawBrand(g, w / 2, 250, 230); }
    g.fillStyle = 'rgba(0,0,0,.5)';
    for (let x = 0; x < w; x += 6) g.fillRect(x, 0, 1, h);
    for (let y = 0; y < h; y += 6) g.fillRect(0, y, w, 1);
    g.fillStyle = 'rgba(0,0,0,.75)';
    for (let x = 0; x <= w; x += 160) g.fillRect(x - 1, 0, 2, h);
    for (let y = 0; y <= h; y += 160) g.fillRect(0, y - 1, w, 2);
    tex.led.needsUpdate = true;
  }

  const M = {};
  function makeMaterials() {
    M.cab = new THREE.MeshStandardMaterial({ color: 0x18191c, roughness: 0.72, metalness: 0.15 });
    const gr = tex.grille.clone(); gr.needsUpdate = true; gr.repeat.set(4, 5);
    M.grille = new THREE.MeshStandardMaterial({ color: 0xffffff, map: gr, roughness: 0.55, metalness: 0.45 });
    const gc = tex.grille.clone(); gc.needsUpdate = true; gc.repeat.set(1, 10);
    M.grilleCol = new THREE.MeshStandardMaterial({ color: 0xffffff, map: gc, roughness: 0.55, metalness: 0.45 });
    M.port = new THREE.MeshStandardMaterial({ color: 0x050505, roughness: 1 });
    M.badge = new THREE.MeshStandardMaterial({ map: tex.rcf, roughness: 0.4 });
    M.alto = new THREE.MeshStandardMaterial({ map: tex.alto, roughness: 0.4 });
    M.pole = new THREE.MeshStandardMaterial({ color: 0x1d1e21, roughness: 0.35, metalness: 0.8 });
    M.alu = new THREE.MeshStandardMaterial({ color: 0xc4c9cf, roughness: 0.28, metalness: 0.95 });
    M.black = new THREE.MeshStandardMaterial({ color: 0x0f1012, roughness: 0.5, metalness: 0.35 });
    M.stage = new THREE.MeshStandardMaterial({ color: 0x17181c, roughness: 0.62, metalness: 0.1 });
    M.skirt = new THREE.MeshStandardMaterial({ color: 0x0b0b0c, roughness: 0.95 });
    M.floor = new THREE.MeshStandardMaterial({ color: 0x0b0c0f, roughness: 0.7, metalness: 0.2 });
    M.drape = new THREE.MeshStandardMaterial({ map: tex.drape, roughness: 0.95 });
    M.totemScreen = new THREE.MeshBasicMaterial({ map: tex.totem, toneMapped: false });
    M.ledScreen = new THREE.MeshBasicMaterial({ map: tex.led, toneMapped: false });
    M.desk = new THREE.MeshStandardMaterial({ color: 0x202226, roughness: 0.5, metalness: 0.4 });
  }

  const box = (w, h, d, m) => new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);

  // RCF EVOX 12: sub bass-reflex, mástil y columna curvada de transductores
  function buildRcf() {
    const g = new THREE.Group();
    const sub = box(0.48, 0.72, 0.64, M.cab); sub.position.y = 0.36; g.add(sub);
    const fr = box(0.44, 0.5, 0.012, M.grille); fr.position.set(0, 0.45, 0.322); g.add(fr);
    const port = box(0.4, 0.06, 0.02, M.port); port.position.set(0, 0.13, 0.322); g.add(port);
    const badge = new THREE.Mesh(new THREE.PlaneGeometry(0.11, 0.04), M.badge); badge.position.set(0.15, 0.66, 0.33); g.add(badge);
    const amp = box(0.3, 0.4, 0.01, M.black); amp.position.set(0, 0.42, -0.325); g.add(amp);
    const foot = box(0.5, 0.02, 0.66, M.black); foot.position.y = 0.01; g.add(foot);
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.019, 0.019, 0.92, 14), M.pole); pole.position.y = 1.18; g.add(pole);
    const col = new THREE.Group(); col.position.y = 1.62; g.add(col);
    for (let i = 0; i < 6; i++) {
      const seg = new THREE.Group();
      seg.position.set(0, 0.09 + i * 0.165, i * i * 0.0025);
      seg.rotation.x = -i * 0.025;
      const body = box(0.1, 0.165, 0.12, M.cab); seg.add(body);
      const gr = box(0.092, 0.158, 0.006, M.grilleCol); gr.position.z = 0.062; seg.add(gr);
      col.add(seg);
    }
    g.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
    return g;
  }

  // Alto TRX315: caja trapezoidal de 15" con bocina, sobre trípode
  function buildTrx() {
    const g = new THREE.Group();
    for (let i = 0; i < 3; i++) {
      const a = i * 2.094 + 0.5;
      strut(new THREE.Vector3(Math.cos(a) * 0.55, 0, Math.sin(a) * 0.55), new THREE.Vector3(0, 0.55, 0), 0.014, M.pole, g);
    }
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.019, 0.019, 1.0, 12), M.pole); pole.position.y = 0.95; g.add(pole);
    const cab = new THREE.Group(); cab.position.y = 1.45; g.add(cab);
    const shape = new THREE.Shape();
    shape.moveTo(-0.24, 0); shape.lineTo(0.24, 0); shape.lineTo(0.2, 0.72); shape.lineTo(-0.2, 0.72); shape.closePath();
    const body = new THREE.Mesh(new THREE.ExtrudeGeometry(shape, { depth: 0.42, bevelEnabled: true, bevelSize: 0.012, bevelThickness: 0.012, bevelSegments: 2 }), M.cab);
    body.position.z = -0.21; cab.add(body);
    const grille = new THREE.Mesh(new THREE.PlaneGeometry(0.42, 0.5), M.grille); grille.position.set(0, 0.29, 0.225); cab.add(grille);
    const horn = box(0.3, 0.13, 0.02, M.port); horn.position.set(0, 0.62, 0.222); cab.add(horn);
    const badge = new THREE.Mesh(new THREE.PlaneGeometry(0.1, 0.035), M.alto); badge.position.set(0, 0.06, 0.23); cab.add(badge);
    g.traverse(o => { if (o.isMesh) o.castShadow = true; });
    return g;
  }

  // Cabeza móvil colgada: base, lira y cabeza con haz volumétrico
  function buildHead() {
    const g = new THREE.Group();
    const base = box(0.3, 0.13, 0.24, M.black); base.position.y = -0.065; g.add(base);
    const clamp = box(0.06, 0.06, 0.06, M.alu); clamp.position.y = 0.03; g.add(clamp);
    const pan = new THREE.Group(); pan.position.y = -0.13; g.add(pan);
    const yTop = box(0.34, 0.035, 0.09, M.black); yTop.position.y = -0.02; pan.add(yTop);
    [-0.155, 0.155].forEach(x => { const a = box(0.035, 0.24, 0.09, M.black); a.position.set(x, -0.14, 0); pan.add(a); });
    const tilt = new THREE.Group(); tilt.position.y = -0.2; pan.add(tilt);
    const head = new THREE.Mesh(new THREE.CylinderGeometry(0.115, 0.1, 0.24, 20), M.black); tilt.add(head);
    const lensMat = new THREE.MeshBasicMaterial({ color: pal.a, toneMapped: false });
    const lens = new THREE.Mesh(new THREE.CircleGeometry(0.085, 24), lensMat); lens.rotation.x = Math.PI / 2; lens.position.y = -0.121; tilt.add(lens);
    const beamGeo = new THREE.ConeGeometry(0.62, 7, 28, 1, true); beamGeo.translate(0, -3.5, 0);
    const beamMat = new THREE.MeshBasicMaterial({ color: pal.a, alphaMap: tex.beam, transparent: true, opacity: 0.1, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false });
    const beam = new THREE.Mesh(beamGeo, beamMat); beam.position.y = -0.12; tilt.add(beam);
    return { g, pan, tilt, lensMat, beamMat };
  }

  // Barra LED de 8 píxeles
  function buildBar() {
    const g = new THREE.Group();
    g.add(box(1.0, 0.07, 0.09, M.black));
    const px = [];
    for (let i = 0; i < 8; i++) {
      const m = new THREE.MeshBasicMaterial({ color: pal.a, toneMapped: false });
      const p = box(0.095, 0.012, 0.06, m); p.position.set(-0.4375 + i * 0.125, 0.04, 0); g.add(p); px.push(m);
    }
    const glowMat = new THREE.MeshBasicMaterial({ color: pal.a, alphaMap: tex.beam, transparent: true, opacity: 0.08, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false });
    const glowGeo = new THREE.CylinderGeometry(0.05, 0.55, 2.2, 4, 1, true); glowGeo.rotateX(Math.PI); glowGeo.translate(0, 1.15, 0);
    const glow = new THREE.Mesh(glowGeo, glowMat); glow.scale.set(1.3, 1, 0.25); g.add(glow);
    return { g, px, glowMat };
  }

  // PAR LED en lira
  function buildPar() {
    const g = new THREE.Group();
    const can = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.1, 0.24, 20, 1, true), M.black); can.rotation.x = Math.PI / 2; g.add(can);
    const back = new THREE.Mesh(new THREE.CircleGeometry(0.1, 20), M.black); back.position.z = -0.12; back.rotation.y = Math.PI; g.add(back);
    const lensMat = new THREE.MeshBasicMaterial({ color: pal.b, toneMapped: false });
    const lens = new THREE.Mesh(new THREE.CircleGeometry(0.095, 20), lensMat); lens.position.z = 0.115; g.add(lens);
    const beamGeo = new THREE.ConeGeometry(0.9, 5, 24, 1, true); beamGeo.translate(0, -2.5, 0); beamGeo.rotateX(-Math.PI / 2);
    const beamMat = new THREE.MeshBasicMaterial({ color: pal.b, alphaMap: tex.beam, transparent: true, opacity: 0.07, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false });
    const beam = new THREE.Mesh(beamGeo, beamMat); beam.position.z = 0.12; g.add(beam);
    return { g, lensMat, beamMat };
  }

  // Tótem LED 55" vertical con pantalla personalizable
  function buildTotem() {
    const g = new THREE.Group();
    const base = box(0.78, 0.05, 0.5, M.alu); base.position.y = 0.025; g.add(base);
    const body = box(0.78, 1.9, 0.07, M.black); body.position.y = 1.0; g.add(body);
    const screen = new THREE.Mesh(new THREE.PlaneGeometry(0.69, 1.22), M.totemScreen); screen.position.set(0, 1.18, 0.0362); g.add(screen);
    const back = box(0.5, 0.6, 0.04, M.cab); back.position.set(0, 1.0, -0.055); g.add(back);
    g.traverse(o => { if (o.isMesh && o !== screen) o.castShadow = true; });
    return g;
  }

  function buildMic() {
    const g = new THREE.Group();
    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.15, 0.02, 24), M.black); base.position.y = 0.01; g.add(base);
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.01, 0.01, 1.35, 8), M.pole); pole.position.y = 0.68; g.add(pole);
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.03, 12, 10), M.grilleCol); head.position.set(0, 1.42, 0.05); g.add(head);
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.013, 0.15, 10), M.black); body.position.set(0, 1.36, 0.02); body.rotation.x = 0.5; g.add(body);
    return g;
  }

  function buildBooth() {
    const g = new THREE.Group();
    const body = box(1.5, 1.0, 0.65, M.black); body.position.y = 0.5; g.add(body);
    const front = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 0.22), new THREE.MeshBasicMaterial({ color: 0xe65837, toneMapped: false }));
    front.position.set(0, 0.82, 0.326); g.add(front);
    rig.boothStrip = front.material;
    [-0.45, 0.45].forEach(x => { const d = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.16, 0.03, 28), M.desk); d.position.set(x, 1.02, 0); g.add(d); });
    const mixer = box(0.32, 0.04, 0.4, M.desk); mixer.position.set(0, 1.02, 0); g.add(mixer);
    g.traverse(o => { if (o.isMesh) o.castShadow = true; });
    return g;
  }

  function buildFoh() {
    const g = new THREE.Group();
    const table = box(1.6, 0.05, 0.8, M.desk); table.position.y = 0.9; g.add(table);
    [-0.75, 0.75].forEach(x => [-0.35, 0.35].forEach(z => { const l = box(0.04, 0.9, 0.04, M.black); l.position.set(x, 0.45, z); g.add(l); }));
    const desk = box(0.8, 0.1, 0.55, M.black); desk.position.set(-0.2, 0.98, 0); desk.rotation.x = -0.12; g.add(desk);
    const scr = new THREE.Mesh(new THREE.PlaneGeometry(0.4, 0.18), new THREE.MeshBasicMaterial({ color: 0x3b82f6, toneMapped: false }));
    scr.position.set(-0.2, 1.12, -0.2); scr.rotation.x = -0.35; scr.rotation.y = Math.PI; g.add(scr);
    const laptop = box(0.32, 0.02, 0.22, M.alu); laptop.position.set(0.5, 0.94, 0); g.add(laptop);
    return g;
  }

  function buildCam() {
    const g = new THREE.Group();
    for (let i = 0; i < 3; i++) {
      const a = i * 2.094;
      strut(new THREE.Vector3(Math.cos(a) * 0.35, 0, Math.sin(a) * 0.35), new THREE.Vector3(0, 1.35, 0), 0.012, M.pole, g);
    }
    const body = box(0.16, 0.18, 0.36, M.black); body.position.y = 1.47; g.add(body);
    const lens = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.06, 0.16, 16), M.black); lens.rotation.x = Math.PI / 2; lens.position.set(0, 1.47, -0.25); g.add(lens);
    const vf = box(0.08, 0.06, 0.08, M.desk); vf.position.set(0.1, 1.58, 0.1); g.add(vf);
    const tally = new THREE.Mesh(new THREE.SphereGeometry(0.012, 8, 6), new THREE.MeshBasicMaterial({ color: 0xff2020, toneMapped: false })); tally.position.set(0, 1.575, -0.12); g.add(tally);
    return g;
  }

  // Pantalla LED modular de w × h metros sobre estructura de aluminio
  function buildLedWall(w, h) {
    const g = new THREE.Group();
    const bottom = h > 1.6 ? 0.6 : 0.9;
    const frame = box(w + 0.08, h + 0.08, 0.1, M.black); frame.position.y = bottom + h / 2; g.add(frame);
    const s = new THREE.Mesh(new THREE.PlaneGeometry(w, h), M.ledScreen); s.position.set(0, bottom + h / 2, 0.051); g.add(s);
    const seams = new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.35 });
    for (let x = -w / 2 + 0.5; x < w / 2 - 0.01; x += 0.5) { const l = new THREE.Mesh(new THREE.PlaneGeometry(0.008, h), seams); l.position.set(x, bottom + h / 2, 0.052); g.add(l); }
    for (let y = 0.5; y < h - 0.01; y += 0.5) { const l = new THREE.Mesh(new THREE.PlaneGeometry(w, 0.008), seams); l.position.set(0, bottom + y, 0.052); g.add(l); }
    [-1, 1].forEach(sx => {
      const x = sx * (w / 2 - 0.15);
      const l = box(0.06, bottom, 0.06, M.alu); l.position.set(x, bottom / 2, -0.05); g.add(l);
      const f = box(0.08, 0.03, 0.8, M.alu); f.position.set(x, 0.015, -0.05); g.add(f);
      const brace = box(0.04, 0.04, 0.6, M.alu); brace.position.set(x, bottom + h * 0.6, -0.35); brace.rotation.x = 0.9; g.add(brace);
    });
    g.traverse(o => { if (o.isMesh && o !== s) o.castShadow = true; });
    return g;
  }

  // Pantalla profesional de 55" en horizontal con pie de suelo
  function buildScreen55() {
    const g = new THREE.Group();
    [-0.3, 0.3].forEach(x => { const f = box(0.06, 0.04, 0.6, M.black); f.position.set(x, 0.02, 0); g.add(f); });
    const bar = box(0.66, 0.05, 0.06, M.black); bar.position.set(0, 0.06, 0); g.add(bar);
    const pole = box(0.08, 1.3, 0.05, M.pole); pole.position.set(0, 0.7, -0.05); g.add(pole);
    const body = box(1.25, 0.72, 0.05, M.black); body.position.set(0, 1.55, 0); g.add(body);
    const scr = new THREE.Mesh(new THREE.PlaneGeometry(1.21, 0.68), M.ledScreen); scr.position.set(0, 1.55, 0.026); g.add(scr);
    g.traverse(o => { if (o.isMesh && o !== scr) o.castShadow = true; });
    return g;
  }

  // DJ animado con auriculares (va dentro de la cabina y se mueve con ella)
  function buildDJ() {
    const g = new THREE.Group();
    const cloth = new THREE.MeshStandardMaterial({ color: 0x1d1f26, roughness: 0.8 });
    const skin = new THREE.MeshStandardMaterial({ color: 0x9c7a63, roughness: 0.7 });
    [-0.1, 0.1].forEach(x => { const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.065, 0.85, 10), cloth); leg.position.set(x, 0.43, 0); g.add(leg); });
    const body = new THREE.Group(); body.position.y = 0.85; g.add(body);
    const torso = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.17, 0.62, 14), cloth); torso.position.y = 0.31; body.add(torso);
    const tee = new THREE.Mesh(new THREE.PlaneGeometry(0.22, 0.12), new THREE.MeshBasicMaterial({ color: 0xe65837, toneMapped: false })); tee.position.set(0, 0.4, 0.19); body.add(tee);
    const head = new THREE.Group(); head.position.y = 0.78; body.add(head);
    head.add(new THREE.Mesh(new THREE.SphereGeometry(0.12, 16, 12), skin));
    const phones = new THREE.Mesh(new THREE.TorusGeometry(0.13, 0.018, 8, 20, Math.PI), M.black); phones.position.y = 0.01; head.add(phones);
    [-1, 1].forEach(sx => { const cup = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.04, 14), M.black); cup.rotation.z = Math.PI / 2; cup.position.set(sx * 0.13, 0, 0); head.add(cup); });
    const arms = [-1, 1].map(sx => {
      const arm = new THREE.Group(); arm.position.set(sx * 0.24, 0.55, 0); body.add(arm);
      const a = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.045, 0.55, 8), cloth); a.position.y = -0.27; arm.add(a);
      const hand = new THREE.Mesh(new THREE.SphereGeometry(0.05, 10, 8), skin); hand.position.y = -0.56; arm.add(hand);
      arm.rotation.x = -0.9; arm.rotation.z = sx * 0.25;
      return arm;
    });
    g.traverse(o => { if (o.isMesh) o.castShadow = true; });
    return { g, body, head, arms };
  }

  // Atril de conferencia con micrófono de cuello de cisne
  function buildLectern() {
    const g = new THREE.Group();
    const base = box(0.6, 0.04, 0.45, M.black); base.position.y = 0.02; g.add(base);
    const col = box(0.5, 1.05, 0.36, M.black); col.position.y = 0.56; g.add(col);
    const strip = new THREE.Mesh(new THREE.PlaneGeometry(0.42, 0.08), new THREE.MeshBasicMaterial({ color: 0xe65837, toneMapped: false })); strip.position.set(0, 0.85, 0.181); g.add(strip);
    rig.lecternStrip = strip.material;
    const top = box(0.62, 0.04, 0.45, M.desk); top.position.set(0, 1.12, -0.02); top.rotation.x = 0.25; g.add(top);
    const neck = new THREE.Mesh(new THREE.TorusGeometry(0.16, 0.008, 6, 16, Math.PI / 1.6), M.pole); neck.position.set(0.12, 1.16, 0.08); neck.rotation.y = Math.PI / 2; g.add(neck);
    const capsule = new THREE.Mesh(new THREE.CylinderGeometry(0.014, 0.01, 0.07, 8), M.black); capsule.position.set(0.12, 1.32, 0.2); capsule.rotation.x = 1.1; g.add(capsule);
    g.traverse(o => { if (o.isMesh) o.castShadow = true; });
    return g;
  }

  /* ---------- Montaje: altura de tarima, colecciones que crecen y ajustes por equipo ---------- */
  const TAR0 = { on: true, w: 7.2, d: 4.2, h: 0.4 }, TAR = Object.assign({}, TAR0), BACK = -2.6;
  let SH = 0.4, trussY = 0.4;
  const CAP = { heads: 48, bars: 24, speakers: 24, mics: 24, screens: 24, totems: 24 };
  const KIND = { trx: 'Altavoz Alto TRX315', speaker: 'Altavoz RCF EVOX 12', totem: 'Tótem', screen: 'Pantalla', mic: 'Micrófono', cam: 'Cámara', wall: 'Pantalla LED', booth: 'Cabina DJ', lectern: 'Atril', foh: 'Control de sonido', head: 'Cabeza móvil' };
  let draggables = [], dragObj = null, selected = null, selBox = null;
  const LOOK = { light: 1, warm: 0, dir: 27 };
  const glb = {};
  const KIND_MODEL = { speaker: ['rcf', 'spk'], trx: ['trx'], totem: ['totem'], screen: ['screen55'], booth: ['booth'], lectern: ['lectern'], mic: ['mic'], cam: ['stream'], foh: ['foh'] };

  function tag(o, kind) { o.userData.kind = kind; o.userData.lift = 0; o.userData.size = 1; o.userData.inch = 55; return o; }
  function addDraggable(o, kind) { tag(o, kind); scene.add(o); draggables.push(o); return o; }
  const onStageAt = (x, z) => TAR.on && Math.abs(x) < TAR.w / 2 + 0.02 && z > BACK - 0.02 && z < BACK + TAR.d + 0.02;
  function place(o, x, z, _legacy, ry) {
    o.userData.onStage = onStageAt(x, z);
    o.position.set(x, (o.userData.onStage ? SH : 0) + o.userData.lift, z);
    if (ry !== undefined) o.rotation.y = ry;
  }
  const fill = (list, n, make) => { while (list.length < n) list.push(make(list.length)); return list; };
  const notify = () => window.dispatchEvent(new CustomEvent('msb:montage'));

  /* Modelos 3D reales (.glb) subidos en WooCommerce: sustituyen al modelo dibujado. */
  function make(kind, fallback) {
    const key = (KIND_MODEL[kind] || []).find(k => glb[k] && glb[k].scene);
    if (!key) return fallback ? fallback() : null;
    const g = new THREE.Group(); g.add(glb[key].scene.clone(true)); g.userData.real = true;
    return g;
  }
  function setModels(map) {
    if (!map || !window.THREE || !THREE.GLTFLoader) return;
    const loader = new THREE.GLTFLoader();
    Object.keys(map).forEach(k => {
      if (!map[k] || glb[k]) return;
      glb[k] = { scene: null };
      loader.load(map[k], g => {
        const sc = g.scene, bb = new THREE.Box3().setFromObject(sc), c = bb.getCenter(new THREE.Vector3());
        sc.position.set(-c.x, -bb.min.y, -c.z);
        sc.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
        glb[k].scene = sc;
        if (inited) swapModels();
      }, undefined, () => { delete glb[k]; });
    });
  }
  function swapModels() {
    draggables.slice().forEach(o => {
      const kind = o.userData.kind;
      if (o.userData.real || !KIND_MODEL[kind]) return;
      const n = make(kind);
      if (!n) return;
      n.position.copy(o.position); n.rotation.copy(o.rotation); n.scale.copy(o.scale);
      n.userData = Object.assign({}, o.userData, { real: true }); n.visible = o.visible;
      if (kind === 'booth') n.add(rig.dj.g);
      scene.remove(o); scene.add(n);
      draggables[draggables.indexOf(o)] = n;
      ['speakers', 'totems', 'screens', 'mics', 'cams', 'trx'].forEach(k => { const j = (rig[k] || []).indexOf(o); if (j >= 0) rig[k][j] = n; });
      ['booth', 'lectern', 'foh'].forEach(k => { if (rig[k] === o) rig[k] = n; });
      if (selected === o) select(n);
    });
  }

  /* Tarima con medidas reales: el fondo queda fijo y crece hacia el público. */
  function buildTarima() {
    if (rig.tarima) scene.remove(rig.tarima);
    const g = new THREE.Group(), { w, d, h } = TAR, front = BACK + d;
    const top = box(w, h, d, M.stage); top.position.set(0, h / 2, BACK + d / 2); top.castShadow = true; top.receiveShadow = true; g.add(top);
    const skirt = box(w + 0.02, Math.max(0.02, h - 0.02), 0.02, M.skirt); skirt.position.set(0, h / 2 - 0.01, front + 0.01); g.add(skirt);
    const n = Math.max(1, Math.round(h / 0.2)), sx = Math.min(w / 2 - 0.6, 3);
    for (let i = 1; i < n + (n === 1 ? 1 : 0); i++) {
      const sh = n === 1 ? h / 2 : i * h / n, st = box(0.9, sh, 0.3, M.stage);
      st.position.set(sx, sh / 2, front + (n - i) * 0.3 - 0.15 + (n === 1 ? 0.3 : 0)); st.castShadow = true; st.receiveShadow = true; g.add(st);
    }
    tag(g, 'tarima'); g.userData.fixed = true; g.visible = TAR.on;
    rig.tarima = g; scene.add(g);
    return g;
  }
  function relevel() {
    SH = TAR.on ? TAR.h : 0;
    rig.tarima.visible = TAR.on;
    trussY = onStageAt(3.2, -2.1) ? SH : 0;
    rig.truss.position.y = trussY - 0.4;
    rig.pars.forEach(p => { p.g.position.y = trussY + 2.3; });
    draggables.forEach(o => place(o, o.position.x, o.position.z));
  }
  function setTarima(o) {
    if (o.w !== undefined) TAR.w = Math.max(1, Math.min(20, o.w));
    if (o.d !== undefined) TAR.d = Math.max(1, Math.min(12, o.d));
    if (o.h !== undefined) TAR.h = Math.max(0.2, Math.min(1.5, o.h));
    const was = selected === rig.tarima;
    buildTarima(); relevel();
    if (was) { selected = rig.tarima; selBox.setFromObject(selected); }
    update(lastState);
  }

  /* Luz para igualar la foto: intensidad, tono (cálido/frío) y dirección de la luz principal. */
  function applyLook() {
    const L = lights, k = LOOK.light, warm = new THREE.Color(0xffc98f), cool = new THREE.Color(0xc4d8ff), white = new THREE.Color(0xfff4ea);
    const tint = LOOK.warm >= 0 ? white.clone().lerp(warm, LOOK.warm) : white.clone().lerp(cool, -LOOK.warm);
    L.key.intensity = 0.95 * k; L.key.color.copy(tint);
    L.hemi.intensity = 0.6 * k; L.hemi.color.copy(tint).lerp(new THREE.Color(0xffffff), 0.4);
    L.front.intensity = 0.35 * k; L.backKey.intensity = 0.45 * k;
    const a = THREE.MathUtils.degToRad(LOOK.dir);
    L.key.position.set(Math.sin(a) * 10.6, 9, Math.cos(a) * 10.6);
  }


  function init() {
    if (inited || failed) return;
    if (!window.THREE || !THREE.OrbitControls) { setTimeout(init, 150); return; }
    const canvas = $('canvas-3d');
    try {
      renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
    } catch (e) { failed = true; $('stage-fallback').hidden = false; return; }
    inited = true;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x08090c);
    scene.fog = new THREE.FogExp2(0x08090c, 0.032);
    camera = new THREE.PerspectiveCamera(42, 1, 0.1, 100);
    controls = new THREE.OrbitControls(camera, canvas);
    controls.enableDamping = true;
    controls.enablePan = false;
    controls.maxPolarAngle = Math.PI / 2 - 0.04;
    controls.minDistance = 2;
    controls.maxDistance = 22;
    controls.addEventListener('end', () => window.dispatchEvent(new CustomEvent('msb:camera')));
    clock = new THREE.Clock();

    makeTextures(); makeMaterials();

    lights.hemi = new THREE.HemisphereLight(0xdbe4f0, 0x1a1e28, 0.6); scene.add(lights.hemi);
    const key = new THREE.DirectionalLight(0xfff4ea, 0.95); lights.key = key;
    key.position.set(4, 9, 8); key.castShadow = true;
    key.shadow.mapSize.set(2048, 2048); key.shadow.bias = -0.0004; key.shadow.radius = 3;
    Object.assign(key.shadow.camera, { left: -12, right: 12, top: 12, bottom: -12, near: 1, far: 40 });
    key.shadow.camera.updateProjectionMatrix();
    scene.add(key);
    const frontFill = new THREE.DirectionalLight(0xbcd2ff, 0.35); frontFill.position.set(-6, 4, 7); scene.add(frontFill); lights.front = frontFill;
    lights.rim = new THREE.DirectionalLight(pal.rim, 1.0); lights.rim.position.set(0, 7, -10); scene.add(lights.rim);
    lights.backFill = new THREE.PointLight(0x22d3ee, 1.1, 24); lights.backFill.position.set(-4, 4.5, -6); scene.add(lights.backFill);
    const backKey = new THREE.DirectionalLight(0xffffff, 0.45); backKey.position.set(3, 5, -9); scene.add(backKey); lights.backKey = backKey;
    lights.a = new THREE.PointLight(pal.a, 1.8, 11); lights.a.position.set(-1.8, 3.3, -1.4); scene.add(lights.a);
    lights.b = new THREE.PointLight(pal.b, 1.6, 11); lights.b.position.set(1.8, 3.3, -1.4); scene.add(lights.b);

    const floor = new THREE.Mesh(new THREE.PlaneGeometry(60, 60), M.floor); rig.floor = floor;
    floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; scene.add(floor);

    buildTarima();
    rig.grid = new THREE.GridHelper(30, 30, 0xe65837, 0xf4f0e8);
    rig.grid.material.transparent = true; rig.grid.material.opacity = 0.35; rig.grid.position.y = 0.004; rig.grid.visible = false; scene.add(rig.grid);

    const drape = new THREE.Mesh(new THREE.PlaneGeometry(9, 5), M.drape); drape.position.set(0, 2.5, -2.75); scene.add(drape); rig.drape = drape;

    rig.truss = new THREE.Group(); scene.add(rig.truss);
    trussRun(new THREE.Vector3(-3.2, 0.4, -2.1), new THREE.Vector3(-3.2, 3.95, -2.1), M.alu, rig.truss);
    trussRun(new THREE.Vector3(3.2, 0.4, -2.1), new THREE.Vector3(3.2, 3.95, -2.1), M.alu, rig.truss);
    trussRun(new THREE.Vector3(-3.35, 3.8, -2.1), new THREE.Vector3(3.35, 3.8, -2.1), M.alu, rig.truss);
    [-3.2, 3.2].forEach(x => { const p = box(0.6, 0.02, 0.6, M.alu); p.position.set(x, 0.41, -2.1); rig.truss.add(p); });

    rig.trx = [0, 1].map(() => addDraggable(make('trx', buildTrx), 'trx'));
    rig.speakers = []; rig.heads = []; rig.bars = []; rig.mics = []; rig.screens = []; rig.totems = []; rig.cams = [];

    rig.pars = [];
    [-1, 1].forEach(sx => { const p = buildPar(); p.g.position.set(sx * 2.95, 2.7, -1.85); p.g.lookAt(sx * 0.6, 0.9, 0.6); scene.add(p.g); rig.pars.push(p); });

    const boothStripHolder = buildBooth();
    rig.booth = addDraggable(make('booth', () => boothStripHolder), 'booth');
    rig.dj = buildDJ(); rig.dj.g.position.set(0, 0, -0.62); rig.booth.add(rig.dj.g);
    const lecternHolder = buildLectern();
    rig.lectern = addDraggable(make('lectern', () => lecternHolder), 'lectern');
    rig.foh = addDraggable(make('foh', buildFoh), 'foh');
    rig.walls = {};
    [['S', 2, 1.5], ['M', 3, 2], ['L', 4, 2.5]].forEach(([k, w, h]) => {
      const wall = addDraggable(buildLedWall(w, h), 'wall');
      wall.userData.dims = [w, h]; wall.userData.base = [w, h]; wall.userData.key = k;
      rig.walls[k] = wall;
    });

    const N = 380, pos = new Float32Array(N * 3);
    for (let i = 0; i < N; i++) { pos[i * 3] = (Math.random() - 0.5) * 9; pos[i * 3 + 1] = 0.4 + Math.random() * 3.8; pos[i * 3 + 2] = -2 + Math.random() * 6; }
    const hg = new THREE.BufferGeometry(); hg.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    rig.haze = new THREE.Points(hg, new THREE.PointsMaterial({ map: tex.puff, size: 1.6, transparent: true, opacity: 0.16, depthWrite: false, color: 0xb8bcc4 }));
    scene.add(rig.haze);

    selBox = new THREE.BoxHelper(undefined, 0xe65837); selBox.visible = false; scene.add(selBox);

    drawTotem();
    if (document.fonts && document.fonts.load) document.fonts.load('60px "Bebas Neue"').then(() => { drawTotem(); drawLed(0); });

    setupDrag(canvas);
    setupFg(canvas);

    const ro = new ResizeObserver(resize); ro.observe(canvas);
    resize();
    setCamPreset('front');
    loop();
  }

  /* Arrastrar mueve el equipo; un toque lo selecciona para ajustarlo; doble clic lo gira 45°. */
  function setupDrag(canvas) {
    const ray = new THREE.Raycaster(), ndc = new THREE.Vector2(), plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
    const hit = new THREE.Vector3(), off = new THREE.Vector3();
    let down = null;
    const aim = e => {
      const r = canvas.getBoundingClientRect();
      ndc.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
      ray.setFromCamera(ndc, camera);
    };
    const pick = e => {
      aim(e);
      const all = draggables.filter(o => o.visible);
      if (rig.tarima.visible) all.push(rig.tarima);
      const hits = ray.intersectObjects(all, true);
      if (!hits.length) return null;
      let o = hits[0].object;
      while (o && !all.includes(o)) o = o.parent;
      return o;
    };
    // Va en fase de captura para adelantarse a OrbitControls y no girar la cámara al arrastrar.
    canvas.addEventListener('pointerdown', e => {
      if (e.button !== 0) return;
      if (fg.calib) { e.stopImmediatePropagation(); e.preventDefault(); calibClick(e); return; }
      down = { x: e.clientX, y: e.clientY, moved: false };
      const o = pick(e);
      if (!o) return;
      if (o.userData.fixed) { down.target = o; return; }
      dragObj = o;
      controls.enabled = false;
      plane.constant = -o.position.y;
      if (ray.ray.intersectPlane(plane, hit)) off.copy(o.position).sub(hit);
      canvas.setPointerCapture(e.pointerId);
      canvas.style.cursor = 'grabbing';
    }, true);
    canvas.addEventListener('pointermove', e => {
      if (down && Math.hypot(e.clientX - down.x, e.clientY - down.y) > 5) down.moved = true;
      if (!dragObj) { if (e.pointerType === 'mouse') canvas.style.cursor = pick(e) ? 'grab' : ''; return; }
      if (!down || !down.moved) return;
      aim(e);
      if (!ray.ray.intersectPlane(plane, hit)) return;
      const x = Math.max(-14, Math.min(14, hit.x + off.x)), z = Math.max(-6, Math.min(16, hit.z + off.z));
      place(dragObj, x, z);
      plane.constant = -dragObj.position.y;
      dragObj.userData.moved = true;
    });
    const end = e => {
      const tap = down && !down.moved;
      if (tap) select(dragObj || down.target || (e.type === 'pointerup' ? pick(e) : null));
      else if (dragObj && dragObj === selected) notify();
      down = null;
      if (!dragObj) return;
      dragObj = null; controls.enabled = true; canvas.style.cursor = '';
    };
    canvas.addEventListener('pointerup', end);
    canvas.addEventListener('pointercancel', end);
    canvas.addEventListener('dblclick', e => {
      const o = pick(e);
      if (o && !o.userData.fixed) { o.rotation.y += Math.PI / 4; o.userData.moved = true; }
    });
  }

  function info(o) {
    if (!o) return null;
    const u = o.userData;
    if (u.kind === 'tarima') return { kind: 'tarima', label: 'Tarima', tarima: Object.assign({}, TAR) };
    return { kind: u.kind, label: KIND[u.kind] || 'Equipo', size: u.size, inch: u.inch, lift: u.lift, dims: u.dims ? u.dims.slice() : null, rot: Math.round(THREE.MathUtils.radToDeg(o.rotation.y)), real: !!u.real };
  }

  function select(o) {
    selected = o || null;
    selBox.visible = !!selected;
    if (selected) selBox.setFromObject(selected);
    window.dispatchEvent(new CustomEvent('msb:select', { detail: info(selected) }));
  }

  function rebuildWall(o, w, h) {
    const n = buildLedWall(w, h);
    n.position.copy(o.position); n.rotation.copy(o.rotation);
    n.userData = Object.assign({}, o.userData, { dims: [w, h] });
    n.visible = o.visible;
    scene.remove(o); scene.add(n);
    draggables[draggables.indexOf(o)] = n;
    rig.walls[o.userData.key] = n;
    return n;
  }

  /* Ajustes del equipo seleccionado desde el panel de montaje. */
  function adjust(prop, v) {
    const o = selected;
    if (!o) return null;
    const u = o.userData;
    let t = o;
    if (prop === 'size') { u.size = Math.max(0.3, Math.min(3, v)); o.scale.setScalar(u.size); }
    else if (prop === 'inch') { u.inch = v; u.size = v / 55; o.scale.setScalar(u.size); }
    else if (prop === 'tarima') { setTarima(v); notify(); return info(rig.tarima); }
    else if (prop === 'lift') { u.lift = Math.max(0, Math.min(6, v)); place(o, o.position.x, o.position.z); }
    else if (prop === 'rot') o.rotation.y += THREE.MathUtils.degToRad(v);
    else if (prop === 'dims' && u.kind === 'wall') t = rebuildWall(o, Math.max(1, Math.min(16, v[0])), Math.max(0.5, Math.min(8, v[1])));
    else if (prop === 'reset' && u.kind === 'tarima') { setTarima(TAR0); notify(); return info(rig.tarima); }
    else if (prop === 'reset') {
      if (u.kind === 'wall' && (u.dims[0] !== u.base[0] || u.dims[1] !== u.base[1])) t = rebuildWall(o, u.base[0], u.base[1]);
      Object.assign(t.userData, { size: 1, inch: 55, lift: 0, moved: false });
      t.scale.setScalar(1);
      update(lastState);
    }
    t.userData.moved = t.userData.moved || prop !== 'reset';
    selected = t;
    selBox.setFromObject(t);
    notify();
    return info(t);
  }

  function resetLayout() {
    draggables.forEach(o => {
      const u = o.userData;
      if (u.kind === 'wall' && (u.dims[0] !== u.base[0] || u.dims[1] !== u.base[1])) rebuildWall(o, u.base[0], u.base[1]);
    });
    draggables.forEach(o => { Object.assign(o.userData, { moved: false, lift: 0, size: 1, inch: 55 }); o.scale.setScalar(1); });
    Object.assign(TAR, { w: TAR0.w, d: TAR0.d, h: TAR0.h }); buildTarima(); relevel();
    select(null);
    update(lastState);
    notify();
  }

  /* Resumen de medidas cambiadas para la propuesta y el WhatsApp. */
  function describe() {
    const out = [];
    Object.values(rig.walls || {}).forEach(w => {
      if (!w.visible) return;
      const [a, b] = w.userData.dims, [a0, b0] = w.userData.base;
      if (a !== a0 || b !== b0) out.push(`Pantalla LED de ${String(a).replace('.', ',')} × ${String(b).replace('.', ',')} m (${String(+(a * b).toFixed(2)).replace('.', ',')} m²) en vez de ${String(a0).replace('.', ',')} × ${String(b0).replace('.', ',')} m`);
    });
    [['screens', 'pantalla'], ['totems', 'tótem']].forEach(([k, name]) => {
      const sizes = {};
      (rig[k] || []).filter(o => o.visible && o.userData.inch !== 55).forEach(o => { sizes[o.userData.inch] = (sizes[o.userData.inch] || 0) + 1; });
      Object.keys(sizes).forEach(i => out.push(`${sizes[i]} ${name}${sizes[i] > 1 ? (name === 'tótem' ? 's' : 's') : ''} de ${i}"`));
    });
    return out;
  }

  function resize() {
    if (!renderer || exporting) return;
    const c = renderer.domElement, w = c.clientWidth, h = c.clientHeight;
    if (!w || !h) return;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    fitBg(w / h);
    layoutFg();
  }

  let cfg = null, ledTick = 0, lastState = null;
  function update(s) {
    if (!inited || !s) return;
    lastState = s;
    mode = s.dm; pal = PAL[mode];
    const p = s.preset, x = s.models;
    const tOn = s.tarimaKnown ? (x.tarima || 0) > 0 : true;
    if (tOn !== TAR.on) { TAR.on = tOn; relevel(); }
    const full = p === 'premium' || p === 'integral';
    const led = x.led_s ? 'S' : x.led_m ? 'M' : x.led_l ? 'L' : '';
    cfg = {
      base: s.guests <= 60 ? 2 : s.guests <= 150 ? 4 : 6,
      extraSpk: x.spk || 0,
      heads: (full ? 4 : 0) + 6 * (x.heads || 0),
      bars: (p === 'corporate' ? 2 : 0) + 4 * (x.bars || 0),
      pars: p === 'corporate' ? 2 : 0,
      mics: ({ starter: 1, corporate: 2, premium: 4, integral: 4 }[p] || 2) + (x.mic || 0),
      dj: (x.dj || 0) > 0,
      booth: p === 'starter' || (x.booth || 0) > 0 || (x.dj || 0) > 0,
      lectern: (x.lectern || 0) > 0,
      foh: p !== 'starter',
      wall: led || (p === 'integral' ? 'S' : ''),
      screens: x.screen55 || 0,
      cams: (p === 'integral' || (x.stream || 0) > 0) ? 2 : 0,
      haze: p === 'premium' || (x.smoke || 0) > 0,
      totems: x.totem || 0
    };
    cfg.truss = p !== 'starter' || cfg.heads > 0 || (x.truss || 0) > 0;
    cfg.trx = p === 'starter';
    cfg.rcfBase = cfg.trx ? 0 : cfg.base;
    cfg.speakers = cfg.rcfBase + cfg.extraSpk;
    const vis = (n, k) => Math.min(n, CAP[k]);

    rig.trx.forEach((t, i) => {
      t.visible = cfg.trx;
      if (t.visible && !t.userData.moved) { const px = i ? 2.9 : -2.9; place(t, px, 1.0, true, -px * 0.06); }
    });

    const xs = { 0: [], 2: [-2.9, 2.9], 4: [-3.3, -2.6, 2.6, 3.3], 6: [-4.3, -3.4, -2.6, 2.6, 3.4, 4.3] }[cfg.rcfBase];
    fill(rig.speakers, vis(cfg.speakers, 'speakers'), () => addDraggable(make('speaker', buildRcf), 'speaker'));
    rig.speakers.forEach((sp, i) => {
      sp.visible = i < vis(cfg.speakers, 'speakers');
      if (!sp.visible || sp.userData.moved) return;
      if (i < xs.length) { const px = xs[i], out = Math.abs(px) > 3.5; place(sp, px, out ? 1.9 : 1.15, !out, -px * 0.05); return; }
      const k = i - xs.length, side = k % 2 ? 1 : -1, px = side * (4.9 + 0.8 * Math.floor(k / 2));
      place(sp, px, 2.3, false, -side * 0.3);
    });

    rig.truss.visible = cfg.truss;
    const nh = vis(cfg.heads, 'heads'), onTruss = Math.min(nh, 12);
    fill(rig.heads, nh, i => { const h = buildHead(); h.phase = i * 0.7; scene.add(h.g); return h; });
    rig.heads.forEach((h, i) => {
      h.g.visible = i < nh;
      if (!h.g.visible) return;
      if (i < 12) { h.g.rotation.x = 0; h.g.position.set(onTruss === 1 ? 0 : -2.85 + i * (5.7 / (onTruss - 1)), trussY + 3.22, -2.1); return; }
      const k = i - 12, side = k % 2 ? 1 : -1, col = Math.floor(k / 2);
      h.g.rotation.x = Math.PI;
      h.g.position.set(side * (3.95 + Math.floor(col / 6) * 0.6), 0, -2.2 + (col % 6) * 0.75);
    });

    const nb = vis(cfg.bars, 'bars');
    fill(rig.bars, nb, () => { const b = buildBar(); scene.add(b.g); return b; });
    rig.bars.forEach((b, i) => {
      b.g.visible = i < nb;
      if (!b.g.visible) return;
      const row = Math.floor(i / 6), inRow = Math.min(6, nb - row * 6), j = i % 6;
      const px = inRow === 1 ? 0 : -2.7 + j * (5.4 / (inRow - 1));
      if (row === 0) b.g.position.set(px, (onStageAt(px, 1.4) ? SH : 0) + 0.035, 1.4);
      else b.g.position.set(px * 1.25, 0.035, 1.9 + row * 0.5);
    });
    rig.pars.forEach(pr => { pr.g.visible = cfg.pars > 0; });

    const micPos = [[0, 0.95], [-1.2, 0.85], [1.2, 0.85], [-2.2, 0.6], [2.2, 0.6], [-0.6, 0.3], [0.6, 0.3], [-1.8, -0.2]];
    const nm = vis(cfg.mics, 'mics');
    fill(rig.mics, nm, () => addDraggable(make('mic', buildMic), 'mic'));
    rig.mics.forEach((m, i) => {
      m.visible = i < nm;
      if (!m.visible || m.userData.moved) return;
      const [mx, mz] = micPos[i] || [-3 + ((i - 8) % 7), -1.2 - Math.floor((i - 8) / 7) * 0.6];
      place(m, mx, mz, true);
    });

    rig.booth.visible = cfg.booth;
    if (!rig.booth.userData.moved) place(rig.booth, 0, -0.7, true, 0);
    rig.dj.g.visible = cfg.dj;
    rig.lectern.visible = cfg.lectern;
    if (!rig.lectern.userData.moved) place(rig.lectern, -2.1, 0.75, true, 0.25);
    rig.foh.visible = cfg.foh;
    if (!rig.foh.userData.moved) place(rig.foh, 0, 7.2, false, Math.PI);
    Object.keys(rig.walls).forEach(k => {
      const w = rig.walls[k];
      w.visible = cfg.wall === k;
      if (!w.userData.moved) place(w, 0, -1.85, true, 0);
    });

    const scrPos = [[-4.7, 3.2, 0.5], [4.7, 3.2, -0.5], [-5.2, 0.4, 0.9], [5.2, 0.4, -0.9]];
    const ns = vis(cfg.screens, 'screens');
    fill(rig.screens, ns, () => addDraggable(make('screen', buildScreen55), 'screen'));
    rig.screens.forEach((sc, i) => {
      sc.visible = i < ns;
      if (!sc.visible || sc.userData.moved) return;
      const k = i - 4, side = k % 2 ? 1 : -1;
      const [px, pz, r] = scrPos[i] || [side * 5.9, 5.4 + Math.floor(k / 2) * 2.2, -side * 1.2];
      place(sc, px, pz, false, r);
    });

    const nc = cfg.cams;
    fill(rig.cams, nc, () => addDraggable(make('cam', buildCam), 'cam'));
    rig.cams.forEach((c, i) => {
      c.visible = i < nc;
      if (!c.visible || c.userData.moved) return;
      const px = i ? 2.6 : -2.6; place(c, px, 5.6, false, Math.atan2(px, 6.6));
    });
    rig.haze.visible = cfg.haze;

    const nt = vis(cfg.totems, 'totems');
    fill(rig.totems, nt, () => addDraggable(make('totem', buildTotem), 'totem'));
    rig.totems.forEach((t, i) => {
      t.visible = i < nt;
      if (!t.visible || t.userData.moved) return;
      if (nt === 1) { place(t, 2.4, 2.6, false, -0.4); return; }
      const side = i % 2 ? 1 : -1, row = Math.floor(i / 2);
      place(t, side * (2.4 + row * 1.3), 2.6 + row * 0.9, false, -side * 0.4);
    });
    if (selected && !selected.visible) select(null);

    lights.a.color.setHex(pal.a); lights.b.color.setHex(pal.b); lights.rim.color.setHex(pal.rim);
    lights.backFill.color.setHex(mode === 'corp' ? 0xcfe0ff : 0x22d3ee);
    const beamOp = cfg.haze ? 0.2 : 0.09;
    rig.heads.forEach((h, i) => { const c = i % 2 ? pal.b : pal.a; h.lensMat.color.setHex(c); h.beamMat.color.setHex(c); h.beamMat.opacity = beamOp; });
    rig.pars.forEach(pr => { pr.lensMat.color.setHex(pal.b); pr.beamMat.color.setHex(pal.b); pr.beamMat.opacity = cfg.haze ? 0.12 : 0.06; });
    rig.bars.forEach(b => { b.glowMat.color.setHex(pal.a); b.glowMat.opacity = cfg.haze ? 0.14 : 0.07; });
    rig.boothStrip.color.setHex(pal.a);
    rig.lecternStrip.color.setHex(pal.a);
    drawLed(clock.getElapsedTime());

    const leg = [];
    if (cfg.trx) leg.push('2 × Alto TRX315');
    if (cfg.speakers) leg.push(`${cfg.speakers} × RCF EVOX 12`);
    if (cfg.heads) leg.push(`${cfg.heads} cabezas móviles`);
    if (cfg.bars) leg.push(`${cfg.bars} barras LED`);
    if (TAR.on && s.tarimaKnown) leg.push(`Tarima ${String(TAR.w).replace('.', ',')} × ${String(TAR.d).replace('.', ',')} m`);
    if (cfg.wall) { const d = rig.walls[cfg.wall].userData.dims; leg.push(`LED ${String(d[0]).replace('.', ',')} × ${String(d[1]).replace('.', ',')} m`); }
    if (cfg.totems) leg.push(`${cfg.totems} tótem${cfg.totems > 1 ? 's' : ''}`);
    if (cfg.screens) leg.push(`${cfg.screens} pantalla${cfg.screens > 1 ? 's' : ''}`);
    if (cfg.dj) leg.push('DJ');
    if (cfg.lectern) leg.push('Atril');
    leg.push(pal.label);
    $('stage-legend').innerHTML = leg.map(t => `<span>${t}</span>`).join('');
  }

  function animateRig(t) {
    if (!cfg) return;
    const speed = mode === 'corp' ? 0.25 : mode === 'amber' ? 0.45 : 0.8;
    rig.heads.forEach((h, i) => {
      if (!h.g.visible) return;
      if (reduce) { h.pan.rotation.y = (i % 2 ? 0.25 : -0.25); h.tilt.rotation.x = -0.45; return; }
      h.pan.rotation.y = Math.sin(t * speed + h.phase) * 0.7;
      h.tilt.rotation.x = -0.35 - 0.3 * Math.sin(t * speed * 1.3 + h.phase * 1.7);
    });
    const ca = new THREE.Color(pal.a), cb = new THREE.Color(pal.b), tmp = new THREE.Color();
    rig.bars.forEach((b, bi) => {
      if (!b.g.visible) return;
      b.px.forEach((m, i) => {
        const k = reduce ? (i % 2) : (Math.sin(t * 3 * speed + i * 0.7 + bi) + 1) / 2;
        m.color.copy(tmp.copy(ca).lerp(cb, k));
      });
    });
    if (!reduce) {
      lights.a.intensity = 1.5 + 0.5 * Math.sin(t * 2 * speed);
      lights.b.intensity = 1.4 + 0.5 * Math.cos(t * 1.7 * speed);
      if (rig.haze.visible) { rig.haze.rotation.y = Math.sin(t * 0.05) * 0.08; rig.haze.position.y = Math.sin(t * 0.3) * 0.08; }
    }
    if (cfg.dj && !reduce) {
      const beat = t * (mode === 'corp' ? 3.2 : 4.4);
      rig.dj.head.rotation.x = 0.18 * Math.max(0, Math.sin(beat));
      rig.dj.body.position.y = 0.85 + 0.03 * Math.abs(Math.sin(beat));
      rig.dj.arms[0].rotation.x = -0.9 + 0.12 * Math.sin(beat * 0.5);
      rig.dj.arms[1].rotation.x = -0.9 - 0.25 * Math.max(0, Math.sin(beat * 0.25 + 1));
    }
    if ((cfg.wall || cfg.screens) && !reduce && ++ledTick % 4 === 0) drawLed(t);
  }

  function loop() {
    requestAnimationFrame(loop);
    if (!active || document.hidden) return;
    const t = clock.getElapsedTime();
    animateRig(t);
    if (rec) {
      const k = Math.min(1, (performance.now() - rec.start) / 1000 / rec.dur);
      const a = rec.a0 + (k - 0.5) * rec.sweep;
      camera.position.set(Math.sin(a) * rec.r, rec.h, Math.cos(a) * rec.r);
      camera.lookAt(controls.target);
    } else controls.update();
    if (selected && selBox.visible) selBox.setFromObject(selected);
    renderer.render(scene, camera);
    if (rec) compose(rec.ctx, rec.mark);
  }

  /* Foto del espacio de fondo, recortada para llenar el encuadre sin deformarse.
     El ángulo de la cámara se refiere a la altura completa de la foto, así el montaje
     encaja igual en pantalla y en la exportación 16:9 aunque el recorte cambie. */
  let bgImg = null, venueFov = 55;
  const imgAspect = () => bgImg.naturalWidth / bgImg.naturalHeight;
  function crop(iw, ih, aspect) {
    return iw / ih > aspect ? { sw: ih * aspect, sh: ih, sx: (iw - ih * aspect) / 2, sy: 0 } : { sw: iw, sh: iw / aspect, sx: 0, sy: (ih - iw / aspect) / 2 };
  }
  function fitBg(aspect) {
    if (!bgImg || !scene.background || !scene.background.isTexture) return;
    const t = scene.background, ia = imgAspect();
    if (ia > aspect) { t.repeat.set(aspect / ia, 1); t.offset.set((1 - aspect / ia) / 2, 0); }
    else { t.repeat.set(1, ia / aspect); t.offset.set(0, (1 - ia / aspect) / 2); }
    camera.fov = ia >= aspect ? venueFov : 2 * Math.atan(Math.tan(venueFov * Math.PI / 360) * ia / aspect) * 180 / Math.PI;
    camera.updateProjectionMatrix();
    drawFg();
  }

  /* Calibración: de 4 esquinas de un rectángulo del suelo (en coordenadas de la foto) a la cámara real. */
  function gauss(A, b) {
    const n = b.length, M = A.map((r, i) => r.concat(b[i]));
    for (let c = 0; c < n; c++) {
      let p = c;
      for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[p][c])) p = r;
      if (Math.abs(M[p][c]) < 1e-12) return null;
      [M[c], M[p]] = [M[p], M[c]];
      for (let r = 0; r < n; r++) {
        if (r === c) continue;
        const k = M[r][c] / M[c][c];
        for (let j = c; j <= n; j++) M[r][j] -= k * M[c][j];
      }
    }
    return M.map((r, i) => r[n] / r[i]);
  }
  // img: 4 puntos [x, y] con y hacia arriba, en unidades de la altura de la foto (y de -1 a 1, x de -aspecto a +aspecto).
  // Orden: fondo-izquierda, fondo-derecha, delante-derecha, delante-izquierda. w × d en metros. fallbackFov en grados.
  function solveCamera(img, w, d, fallbackFov) {
    const src = [[-w / 2, -d / 2], [w / 2, -d / 2], [w / 2, d / 2], [-w / 2, d / 2]];
    const dst = img.map(([x, y]) => [x, -y]);
    const A = [], b = [];
    for (let i = 0; i < 4; i++) {
      const [X, Z] = src[i], [x, y] = dst[i];
      A.push([X, Z, 1, 0, 0, 0, -x * X, -x * Z]); b.push(x);
      A.push([0, 0, 0, X, Z, 1, -y * X, -y * Z]); b.push(y);
    }
    const h = gauss(A, b);
    if (!h) return { ok: false, msg: 'Los 4 puntos están alineados. Marca las esquinas de un rectángulo.' };
    const [h11, h12, h13, h21, h22, h23, h31, h32] = h, h33 = 1;
    const f2 = -(h11 * h12 + h21 * h22) / (h31 * h32);
    let f = 1 / Math.tan(fallbackFov * Math.PI / 360), estimated = false;
    if (isFinite(f2) && f2 > 0) {
      const fov = 2 * Math.atan(1 / Math.sqrt(f2)) * 180 / Math.PI;
      if (fov > 15 && fov < 110) { f = Math.sqrt(f2); estimated = true; }
    }
    const v = (a, c, e) => [a, c, e];
    const nrm = a => Math.hypot(a[0], a[1], a[2]);
    const dot = (a, c) => a[0] * c[0] + a[1] * c[1] + a[2] * c[2];
    const cross = (a, c) => [a[1] * c[2] - a[2] * c[1], a[2] * c[0] - a[0] * c[2], a[0] * c[1] - a[1] * c[0]];
    const sc = (a, k) => a.map(q => q * k);
    const b1 = v(h11 / f, h21 / f, h31), b2 = v(h12 / f, h22 / f, h32), b3 = v(h13 / f, h23 / f, h33);
    let lam = 2 / (nrm(b1) + nrm(b2));
    if (b3[2] * lam < 0) lam = -lam;
    const r1 = sc(b1, lam / nrm(sc(b1, lam)) * 1);
    let r2 = sc(b2, lam);
    r2 = r2.map((q, i) => q - r1[i] * dot(r1, r2)); r2 = sc(r2, 1 / nrm(r2));
    const ry = cross(r2, r1), t = sc(b3, lam);
    // R (cámara ← mundo) con columnas X = r1, Y = r2 × r1, Z = r2. Filas = ejes de la cámara en el mundo.
    const row = i => [r1[i], ry[i], r2[i]];
    const right = row(0), down = row(1), fwd = row(2);
    const C = [0, 1, 2].map(i => -(right[i] * t[0] + down[i] * t[1] + fwd[i] * t[2]));
    if (C[1] < 0.2 || fwd[1] > 0.2) return { ok: false, msg: 'No encaja. Marca las esquinas en este orden: fondo izquierda, fondo derecha, delante derecha, delante izquierda.' };
    const depth = -dot(C, fwd);
    return { ok: true, pos: C, fwd, up: sc(down, -1), fov: 2 * Math.atan(1 / f) * 180 / Math.PI, estimated, depth };
  }

  /* Capa de primer plano: lo que se pinta sobre la foto queda por delante de los equipos. */
  const fg = { el: null, ctx: null, photo: null, mask: null, cut: null, tint: null, mode: null, brush: 40, has: false, pts: null, calib: null };
  function setupFg(canvas) {
    const el = document.createElement('canvas');
    el.className = 'fg-layer'; el.setAttribute('aria-hidden', 'true');
    canvas.parentNode.insertBefore(el, canvas.nextSibling);
    fg.el = el; fg.ctx = el.getContext('2d');
    let painting = false;
    const at = e => {
      const r = el.getBoundingClientRect(), c = crop(fg.photo.width, fg.photo.height, r.width / r.height);
      return [c.sx + (e.clientX - r.left) / r.width * c.sw, c.sy + (e.clientY - r.top) / r.height * c.sh, fg.brush * c.sw / r.width];
    };
    const dab = e => {
      const [x, y, rad] = at(e), m = fg.mask.getContext('2d');
      m.globalCompositeOperation = fg.mode === 'erase' ? 'destination-out' : 'source-over';
      m.fillStyle = '#000'; m.beginPath(); m.arc(x, y, rad, 0, Math.PI * 2); m.fill();
      fg.has = true; rebuildCut();
    };
    el.addEventListener('pointerdown', e => { if (!fg.mode) return; painting = true; el.setPointerCapture(e.pointerId); dab(e); });
    el.addEventListener('pointermove', e => { if (painting) dab(e); });
    const stop = () => { painting = false; };
    el.addEventListener('pointerup', stop); el.addEventListener('pointercancel', stop);
  }
  function layoutFg() {
    if (!fg.el) return;
    const c = renderer.domElement, dpr = Math.min(window.devicePixelRatio, 2);
    Object.assign(fg.el.style, { left: c.offsetLeft + 'px', top: c.offsetTop + 'px', width: c.clientWidth + 'px', height: c.clientHeight + 'px' });
    fg.el.width = Math.round(c.clientWidth * dpr); fg.el.height = Math.round(c.clientHeight * dpr);
    drawFg();
  }
  let cutQueued = false;
  function rebuildCut() {
    if (cutQueued) return;
    cutQueued = true;
    requestAnimationFrame(() => {
      cutQueued = false;
      const g = fg.cut.getContext('2d');
      g.globalCompositeOperation = 'copy'; g.drawImage(fg.mask, 0, 0);
      g.globalCompositeOperation = 'source-in'; g.drawImage(fg.photo, 0, 0);
      const t = fg.tint.getContext('2d');
      t.globalCompositeOperation = 'copy'; t.drawImage(fg.mask, 0, 0);
      t.globalCompositeOperation = 'source-in'; t.fillStyle = 'rgba(230,88,55,.45)'; t.fillRect(0, 0, fg.tint.width, fg.tint.height);
      drawFg();
    });
  }
  function drawFg() {
    if (!fg.el || exporting) return;
    const g = fg.ctx, W = fg.el.width, H = fg.el.height;
    g.clearRect(0, 0, W, H);
    fg.el.style.pointerEvents = fg.mode ? 'auto' : 'none';
    fg.el.style.cursor = fg.mode ? 'crosshair' : '';
    if (!bgImg || !fg.photo) return;
    const c = crop(fg.photo.width, fg.photo.height, W / H);
    if (fg.has) {
      g.drawImage(fg.cut, c.sx, c.sy, c.sw, c.sh, 0, 0, W, H);
      if (fg.mode) g.drawImage(fg.tint, c.sx, c.sy, c.sw, c.sh, 0, 0, W, H);
    }
    if (fg.pts && fg.pts.length) {
      const P = fg.pts.map(([nx, ny]) => [(nx + 1) / 2 * W, (1 - ny) / 2 * H]);
      g.strokeStyle = '#E65837'; g.fillStyle = '#E65837'; g.lineWidth = 2 * W / fg.el.clientWidth;
      g.beginPath(); P.forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y))); if (P.length === 4) g.closePath(); g.stroke();
      P.forEach(([x, y], i) => { g.beginPath(); g.arc(x, y, 7 * W / fg.el.clientWidth, 0, Math.PI * 2); g.fill(); g.fillStyle = '#0A0A0A'; g.font = `bold ${Math.round(11 * W / fg.el.clientWidth)}px sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(String(i + 1), x, y); g.fillStyle = '#E65837'; });
    }
  }
  function initFgPhoto(img) {
    const k = Math.min(1, 2560 / Math.max(img.naturalWidth, img.naturalHeight));
    const mk = () => { const c = document.createElement('canvas'); c.width = Math.round(img.naturalWidth * k); c.height = Math.round(img.naturalHeight * k); return c; };
    fg.photo = mk(); fg.photo.getContext('2d').drawImage(img, 0, 0, fg.photo.width, fg.photo.height);
    fg.mask = mk(); fg.cut = mk(); fg.tint = mk(); fg.has = false; fg.pts = null;
  }

  /* Luz inicial a partir de la foto: brillo medio, tono y lado por el que entra la luz. */
  function autoLook() {
    if (!fg.photo) return null;
    const c = document.createElement('canvas'); c.width = 48; c.height = 27;
    const g = c.getContext('2d'); g.drawImage(fg.photo, 0, 0, 48, 27);
    const d = g.getImageData(0, 0, 48, 27).data, cols = new Array(48).fill(0);
    let R = 0, G = 0, B = 0, L = 0, L2 = 0;
    for (let i = 0; i < d.length; i += 4) {
      const l = (0.2126 * d[i] + 0.7152 * d[i + 1] + 0.0722 * d[i + 2]) / 255;
      R += d[i]; G += d[i + 1]; B += d[i + 2]; L += l; L2 += l * l; cols[(i / 4) % 48] += l;
    }
    const n = d.length / 4; L /= n; R /= n; G /= n; B /= n;
    const sd = Math.sqrt(Math.max(0, L2 / n - L * L));
    const peak = cols.indexOf(Math.max(...cols)), side = peak / 47 * 2 - 1;
    const v = {
      light: Math.max(0.4, Math.min(1.8, 0.45 + L * 1.4)),
      warm: Math.max(-1, Math.min(1, (R - B) / (Math.max(R, G, B) + 1) * 3)),
      dir: (360 + Math.round(side * 70)) % 360,
      shadow: Math.max(0.25, Math.min(0.7, 0.2 + sd * 1.6))
    };
    setView(v);
    return v;
  }

  function startCalib(w, d) {
    if (!bgImg) return;
    fg.calib = { w, d }; fg.pts = []; fg.mode = null; drawFg();
    window.dispatchEvent(new CustomEvent('msb:calib', { detail: { step: 0 } }));
  }
  function calibClick(e) {
    const r = renderer.domElement.getBoundingClientRect();
    const nx = ((e.clientX - r.left) / r.width) * 2 - 1, ny = -((e.clientY - r.top) / r.height) * 2 + 1;
    fg.pts.push([nx, ny]); drawFg();
    if (fg.pts.length < 4) { window.dispatchEvent(new CustomEvent('msb:calib', { detail: { step: fg.pts.length } })); return; }
    const a = camera.aspect, ia = imgAspect();
    const img = fg.pts.map(([x, y]) => (ia >= a ? [x * a / ia, y] : [x, y * ia / a])).map(([u, v]) => [u * ia, v]);
    const res = solveCamera(img, fg.calib.w, fg.calib.d, venueFov);
    fg.calib = null;
    if (res.ok) {
      venueFov = res.fov;
      controls.maxDistance = Math.max(22, res.depth * 1.5);
      camera.position.set(...res.pos);
      controls.target.set(res.pos[0] + res.fwd[0] * res.depth, res.pos[1] + res.fwd[1] * res.depth, res.pos[2] + res.fwd[2] * res.depth);
      fitBg(camera.aspect);
      controls.update();
      setTimeout(() => { fg.pts = null; drawFg(); }, 1500);
    } else { fg.pts = null; drawFg(); }
    window.dispatchEvent(new CustomEvent('msb:calib', { detail: { done: true, ok: res.ok, msg: res.msg || '', fov: res.ok ? Math.round(res.fov) : 0, height: res.ok ? +res.pos[1].toFixed(2) : 0, estimated: !!res.estimated } }));
  }
  function setVenue(img) {
    if (!inited) return;
    bgImg = img || null;
    fg.calib = null; fg.mode = null;
    if (img) {
      initFgPhoto(img);
      const t = new THREE.Texture(img); t.needsUpdate = true;
      scene.background = t; scene.fog = null;
      rig.floor.material = new THREE.ShadowMaterial({ opacity: 0.45 });
      rig.drape.visible = false;
      fitBg(camera.aspect);
      // La propia foto se usa como entorno: el metal y las pantallas reflejan los colores de la sala.
      try {
        const pm = new THREE.PMREMGenerator(renderer);
        if (scene.environment) scene.environment.dispose();
        scene.environment = pm.fromEquirectangular(t).texture;
        pm.dispose();
      } catch (e) { scene.environment = null; }
      setView({ height: 1.6, aim: 1.3, fov: 55, dist: 12 });
      autoLook();
    } else {
      scene.background = new THREE.Color(0x08090c); scene.fog = new THREE.FogExp2(0x08090c, 0.032);
      if (scene.environment) { scene.environment.dispose(); scene.environment = null; }
      Object.assign(LOOK, { light: 1, warm: 0, dir: 27 }); applyLook(); rig.grid.visible = false;
      fg.photo = null; fg.has = false; fg.pts = null; drawFg();
      camera.fov = 42; camera.updateProjectionMatrix(); controls.maxDistance = 22;
      rig.floor.material = M.floor;
      rig.drape.visible = true;
    }
  }

  /* Encaje de la cámara con la foto: altura, distancia, lente y punto de mira. */
  function getView() {
    const off = new THREE.Vector3().subVectors(camera.position, controls.target);
    return { height: +camera.position.y.toFixed(2), dist: +Math.hypot(off.x, off.z).toFixed(2), fov: Math.round(bgImg ? venueFov : camera.fov), aim: +controls.target.y.toFixed(2), shadow: rig.floor.material.isShadowMaterial ? rig.floor.material.opacity : 0.45, light: LOOK.light, warm: LOOK.warm, dir: LOOK.dir, grid: rig.grid.visible };
  }
  function setView(v) {
    if (!inited) return;
    const off = new THREE.Vector3().subVectors(camera.position, controls.target);
    const ang = Math.atan2(off.x, off.z);
    if (v.aim !== undefined) controls.target.y = v.aim;
    const dist = v.dist !== undefined ? v.dist : Math.hypot(off.x, off.z);
    const height = v.height !== undefined ? v.height : camera.position.y;
    camera.position.set(controls.target.x + Math.sin(ang) * dist, height, controls.target.z + Math.cos(ang) * dist);
    if (v.fov !== undefined) { if (bgImg) { venueFov = v.fov; fitBg(camera.aspect); } else { camera.fov = v.fov; camera.updateProjectionMatrix(); } }
    if (v.shadow !== undefined && rig.floor.material.isShadowMaterial) rig.floor.material.opacity = v.shadow;
    if (v.light !== undefined || v.warm !== undefined || v.dir !== undefined) {
      ['light', 'warm', 'dir'].forEach(k => { if (v[k] !== undefined) LOOK[k] = v[k]; });
      applyLook();
    }
    if (v.grid !== undefined) rig.grid.visible = !!v.grid;
    controls.update();
  }

  /* Exportación: 1080p para todos; 1440p y 4K para el equipo. Marca de agua opcional. */
  let exporting = false;
  function hiRes(w, h) {
    exporting = true;
    const prevPR = renderer.getPixelRatio();
    renderer.setPixelRatio(1); renderer.setSize(w, h, false);
    camera.aspect = w / h; camera.updateProjectionMatrix();
    fitBg(w / h);
    const selVis = selBox.visible, gridVis = rig.grid.visible; selBox.visible = false; rig.grid.visible = false;
    return () => { exporting = false; selBox.visible = selVis; rig.grid.visible = gridVis; renderer.setPixelRatio(prevPR); resize(); };
  }

  function watermark(g, w, h) {
    const u = h / 1080, txt = 'PROPUESTA · MEDIA SHOW BCN';
    g.save();
    g.globalAlpha = 0.1; g.fillStyle = '#ffffff';
    g.font = `${Math.round(46 * u)}px "Bebas Neue", Impact, sans-serif`;
    const step = g.measureText(txt).width + 160 * u;
    g.translate(w / 2, h / 2); g.rotate(-0.35);
    for (let r = -6; r <= 6; r++) for (let x = -w; x < w; x += step) g.fillText(txt, x + (r % 2 ? step / 2 : 0), r * 190 * u);
    g.restore();
  }
  function badge(g, w, h) {
    const u = h / 1080, a = 'MEDIA SHOW BCN', b2 = 'mediashowbcn.com · 615 78 20 87';
    g.save();
    g.textBaseline = 'middle';
    const fa = `${Math.round(34 * u)}px "Bebas Neue", Impact, sans-serif`, fb = `500 ${Math.round(18 * u)}px "Work Sans", sans-serif`;
    g.font = fa; const wa = g.measureText(a).width;
    g.font = fb; const wb = g.measureText(b2).width;
    const ph = 64 * u, pw = 26 * u + wa + 20 * u + wb + 24 * u, x = w - pw - 32 * u, y = h - ph - 28 * u;
    g.fillStyle = 'rgba(10,10,10,.72)'; g.fillRect(x, y, pw, ph);
    g.fillStyle = '#E65837'; g.fillRect(x, y, 8 * u, ph);
    g.font = fa; g.fillStyle = '#F4F0E8'; g.fillText(a, x + 26 * u, y + ph / 2);
    g.font = fb; g.fillStyle = '#A6A49E'; g.fillText(b2, x + 26 * u + wa + 20 * u, y + ph / 2);
    g.restore();
  }
  function compose(ctx, mark) {
    const c = ctx.canvas;
    ctx.drawImage(renderer.domElement, 0, 0, c.width, c.height);
    if (bgImg && fg.has) { const k = crop(fg.cut.width, fg.cut.height, c.width / c.height); ctx.drawImage(fg.cut, k.sx, k.sy, k.sw, k.sh, 0, 0, c.width, c.height); }
    if (mark) watermark(ctx, c.width, c.height);
    badge(ctx, c.width, c.height);
  }

  function snapshot(opt) {
    const o = Object.assign({ w: 1920, h: 1080, mark: true }, opt);
    return new Promise((resolve, reject) => {
      if (!inited) return reject(new Error('El escenario 3D no está listo.'));
      const restore = hiRes(o.w, o.h);
      renderer.render(scene, camera);
      const c = document.createElement('canvas'); c.width = o.w; c.height = o.h;
      compose(c.getContext('2d'), o.mark);
      restore();
      c.toBlob(b => { b ? resolve(b) : reject(new Error('No se ha podido crear la imagen.')); }, 'image/png');
    });
  }

  let rec = null;
  function record(seconds, opt) {
    const o = Object.assign({ w: 1920, h: 1080, mark: true }, opt);
    return new Promise((resolve, reject) => {
      if (!inited) return reject(new Error('El escenario 3D no está listo.'));
      const c = document.createElement('canvas'); c.width = o.w; c.height = o.h;
      if (!window.MediaRecorder || !c.captureStream) return reject(new Error('Este navegador no permite grabar vídeo. Prueba con Chrome, Edge o Safari actualizados.'));
      const type = ['video/mp4;codecs=avc1', 'video/mp4', 'video/webm;codecs=vp9', 'video/webm'].find(t => MediaRecorder.isTypeSupported(t));
      if (!type) return reject(new Error('Este navegador no permite grabar vídeo. Prueba con Chrome, Edge o Safari actualizados.'));
      const saved = camera.position.clone();
      const off = new THREE.Vector3().subVectors(saved, controls.target);
      // Con foto de fondo la cámara apenas se mueve para que el montaje siga encajando.
      const sweep = bgImg ? 0.12 : Math.PI * 0.9;
      rec = { start: performance.now(), dur: seconds, sweep, r: bgImg ? Math.hypot(off.x, off.z) : Math.max(8, Math.hypot(off.x, off.z)), h: bgImg ? saved.y : Math.max(2.4, saved.y), a0: Math.atan2(off.x, off.z), ctx: c.getContext('2d'), mark: o.mark };
      const restore = hiRes(o.w, o.h);
      const chunks = [];
      const mr = new MediaRecorder(c.captureStream(30), { mimeType: type, videoBitsPerSecond: o.w > 1920 ? 30e6 : 12e6 });
      mr.ondataavailable = e => { if (e.data.size) chunks.push(e.data); };
      mr.onstop = () => {
        rec = null; restore();
        camera.position.copy(saved); controls.update();
        resolve({ blob: new Blob(chunks, { type }), ext: type.startsWith('video/mp4') ? 'mp4' : 'webm' });
      };
      mr.start(500);
      setTimeout(() => mr.stop(), seconds * 1000);
    });
  }

  function setCam(pos) {
    if (!inited) return;
    camera.position.set(...pos);
    controls.target.set(0, 1.6, 0);
    controls.update();
  }

  return {
    init,
    update,
    setActive(v) { active = v; if (v) resize(); },
    setLogo(img) { logoImg = img; if (inited) { drawTotem(); drawLed(clock.getElapsedTime()); } },
    resetLayout() { if (inited) resetLayout(); },
    setVenue,
    getView() { return inited ? getView() : null; },
    setView,
    adjust,
    select(o) { if (!inited) return; if (o === 'tarima') { if (rig.tarima.visible) select(rig.tarima); } else if (!o) select(null); },
    tarima() { return Object.assign({}, TAR); },
    setModels(map) { setModels(map); },
    calibrate(w, d) { if (inited) startCalib(w, d); },
    cancelCalib() { fg.calib = null; fg.pts = null; drawFg(); },
    paint(mode) { fg.mode = mode || null; fg.calib = null; if (fg.mask) rebuildCut(); drawFg(); },
    brush(px) { fg.brush = px; },
    clearFg() { if (!fg.mask) return; fg.mask.getContext('2d').clearRect(0, 0, fg.mask.width, fg.mask.height); fg.has = false; rebuildCut(); },
    autoLook() { return inited ? autoLook() : null; },
    describe() { return inited ? describe() : []; },
    snapshot,
    record,
    get recording() { return !!rec; },
    cam(preset) {
      const presets = { front: [0, 3.4, 10], audience: [5.5, 2.2, 8.5], back: [0.8, 3.6, -9.5] };
      setCam(presets[preset] || presets.front);
    }
  };
})();

  function setCamPreset(p) { Stage.cam(p); syncView(); }

  function resetLayout() { Stage.resetLayout(); render(); }

  Object.assign(window, { switchView, goHome, selectPillar, openQuoterWithPreset, openQuoterWithPack, toggleProposal, printProposal, setCamPreset, resetLayout, msbApplyConfig: applyConfig });

  buildSelects();
  buildExtrasList();
  setupLogo();
  setupExport();
  setupFit();
  setupInspector();
  setupAddBar();
  setupIntegrate();
  if (D.models3d) Stage.setModels(D.models3d);
  if (S.pro) document.querySelectorAll('.pro-only').forEach(el => { el.hidden = false; });
  else $('export-note').hidden = false;
  syncInputs();
  ['guests-range', 'pack-select', 'hours-select', 'space-select', 'zone-select', 'dm-select', 'date-input', 'client-name', 'client-phone']
    .forEach(id => $(id).addEventListener(id === 'guests-range' || id.startsWith('client') ? 'input' : 'change', render));
  $('consent-check').addEventListener('change', () => { $('wa-msg').textContent = ''; render(); });
  $('wa-quote-btn').addEventListener('click', e => {
    if (!$('consent-check').checked) {
      e.preventDefault();
      $('wa-msg').textContent = 'Marca la casilla de privacidad para enviar tu resumen por WhatsApp.';
      $('consent-check').focus();
    }
  });
  $('reserve-btn').addEventListener('click', reserve);
  $('date-input').min = new Date().toISOString().slice(0, 10);
  render();

  const params = new URLSearchParams(location.search);
  const packParam = params.get('msb_pack');
  let cfgParam = null;
  try { cfgParam = JSON.parse(params.get('msb_cfg') || 'null'); } catch (e) { cfgParam = null; }
  if (cfgParam) applyConfig(cfgParam);
  else if (packParam && packById(packParam)) openQuoterWithPack(packParam);
  else if (location.hash === '#cotizador') switchView('quoter', false);
})();
